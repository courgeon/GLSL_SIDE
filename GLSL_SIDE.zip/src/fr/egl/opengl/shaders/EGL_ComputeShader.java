package fr.egl.opengl.shaders;

import java.io.File;

import org.lwjgl.opengl.*;
import static org.lwjgl.opengl.GL20.*;

public class EGL_ComputeShader  {


	int CS_location = -1   ;
	String CS_code  = null ;
	String CS_PATH = null;
	File CS_FILE = null;
	String CS_Tag;
	EGL_Shader_Defs def;
	EGL_Shader_Injection[] injections;

	public EGL_ComputeShader(String path){
		this(path, null, null, null);
	}
	public EGL_ComputeShader(String path,EGL_Shader_Defs defs){
		this(path, null,null, defs);
	}	
	public EGL_ComputeShader(String path, String CS_Tag){
		this(path, CS_Tag,null, null);
	}


	public EGL_ComputeShader(String path, EGL_Shader_Injection[] injections){
		this(path, null, injections,null);
	}
	public EGL_ComputeShader(String path, EGL_Shader_Injection[] injections,EGL_Shader_Defs defs){
		this(path, null, injections,defs);
	}	
	public EGL_ComputeShader(String path,  String CS_Tag, EGL_Shader_Injection[] injections){
		this(path, CS_Tag, injections,null);
	}


	public EGL_ComputeShader(String path, String cs_tag, EGL_Shader_Injection [] injections, EGL_Shader_Defs defs ){

		if (injections == null)
			injections = new EGL_Shader_Injection[0];


		this.injections = injections;

		CS_Tag = cs_tag;
		CS_PATH = path;
		CS_FILE = new File(CS_PATH);
		def = defs;
/*
		instanceShaderID = EGL_ShaderManager.createProgramID();


		CS_location = GL20.glCreateShader(GL43.GL_COMPUTE_SHADER);

		byte[] source= EGL_ShaderManager.getProgramCode(path+(CS_Tag!=null?"#?"+CS_Tag:""),"CS",injections,defs != null?defs.list:new String[0] );
		CS_code = new String(source);

		glShaderSource(CS_location, CS_code );
		glCompileShader(CS_location);

		System.out.println("CS compilation Status : " + (glGetShaderi(CS_location, GL_COMPILE_STATUS)==GL11.GL_FALSE? "FALSE" : "TRUE"));
		EGL_ShaderManager.printLogInfo(CS_location);
		if(EGL_ShaderManager.glError()){System.out.println("Error while loading CS");	}

		glAttachShader(instanceShaderID, CS_location);

		if(EGL_ShaderManager.glError()){System.out.println("Error while attaching CS");	}

		glLinkProgram(instanceShaderID);

		if(EGL_ShaderManager.glError()){System.out.println("Error while linking CS");	}

		glUseProgram(instanceShaderID);
*/
	}



}


