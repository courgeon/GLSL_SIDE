/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */


package fr.egl.widgets.code_editor;

import java.awt.AWTEvent;
import java.awt.Adjustable;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.EventListenerList;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.Segment;
import javax.swing.text.Utilities;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;
import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEdit;
import javax.tools.Diagnostic.Kind;

import fr.egl.glsl_editor.MainEditor;
import fr.egl.glsl_editor.MainMenu;
import fr.egl.glsl_editor.SaveListener;
import fr.egl.glsl_editor.SuggestionPanel;
import fr.egl.glsl_editor.TypeSelector.ShaderType;
import fr.egl.widgets.code_editor.syntax.SyntaxToken;
import fr.egl.widgets.code_editor.syntax.SyntaxTokenMarker;

/**
 * jEdit's text area component. It is more suited for editing program
 * source code than JEditorPane, because it drops the unnecessary features
 * (images, variable-width lines, and so on) and adds a whole bunch of
 * useful goodies such as:
 * <ul>
 * <li>More flexible key binding scheme
 * <li>Supports macro recorders
 * <li>Rectangular selection
 * <li>Bracket highlighting
 * <li>Syntax highlighting
 * <li>Command repetition
 * <li>Block caret can be enabled
 * </ul>
 * It is also faster and doesn't have as many problems. It can be used
 * in other applications; the only other part of jEdit it depends on is
 * the syntax package.<p>
 *
 * To use it in your app, treat it like any other component, for example:
 * <pre>JEditTextArea ta = new JEditTextArea();
 * ta.setTokenMarker(new JavaTokenMarker());
 * ta.setText("public class Test {\n"
 *     + "    public static void main(String[] args) {\n"
 *     + "        System.out.println(\"Hello World\");\n"
 *     + "    }\n"
 *     + "}");</pre>
 */
public class JCodeTextArea extends JComponent implements MouseMotionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	/**
	 * Adding components with this name to the text area will place
	 * them left of the horizontal scroll bar. In jEdit, the status
	 * bar is added this way.
	 */
	public static String LEFT_OF_SCROLLBAR = "los";

	public File associatedFile;

	/**
	 * Creates a new JEditTextArea with the default settings.
	 */

	public String toString(){
		return associatedFile.getName();
	}

	public Vector<String> sections;
	public Vector<ShaderType> types ;

	public Hashtable<String, String> inclusions;
	long lastModif ;
	boolean modified = false, unsaved = false;
	
	public void saved(boolean b){
		unsaved = !b;
		if (saveLis != null)
			saveLis.setSaved(!unsaved);
	}
	
	public JCodeTextArea(File p, Vector<String> sections, Vector<ShaderType> types, Hashtable<String, String> inclusions  )
	{
		this(new TextAreaDefaults());
		associatedFile = p;
		this.inclusions = inclusions;
		this.sections = sections;
		this.types = types;
		lastModif = System.currentTimeMillis();

		new Thread(){
			public void run(){
				while(true){
					try{
						Thread.sleep(1000);
						if (modified && System.currentTimeMillis()-lastModif>3000){
							modified = false;
							if (! SuggestionPanel.isVisible())
								MainEditor.compileShader(JCodeTextArea.this);
						}
					}catch(Exception e){};
				}
			}
		}.start();


		this.document.addDocumentListener(new DocumentListener() {

			@Override
			public void removeUpdate(DocumentEvent e) {
				modified = true;
				if (saveLis != null)
					saveLis.setSaved(false);
				unsaved = true;
				lastModif = System.currentTimeMillis();
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				modified = true;
				if (saveLis != null)
					saveLis.setSaved(false);
				unsaved = true;
				lastModif = System.currentTimeMillis();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				modified = true;
				if (saveLis != null)
					saveLis.setSaved(false);
				unsaved = true;
				lastModif = System.currentTimeMillis();
			}
		}); 


	}

	SaveListener saveLis;
	public void setSaveListener(SaveListener listener){
		saveLis = listener;
	}

	public String getTextWithInclusion(){
		String original = this.getText();
		for(String key : inclusions.keySet()){
			System.out.println("replacing key " + key + " with  " + inclusions.get(key));
			System.out.println("---------------------");
			original = original.replace(key, inclusions.get(key));
		}
		return original;
	}

	//UndoRedoText undoredo_tool;


	PopupInfoBox popupInfo;


	protected UndoManager undoManager = new UndoManager();

	/**
	 * Creates a new JEditTextArea with the specified settings.
	 * @param defaults The default settings
	 */
	public JCodeTextArea(TextAreaDefaults defaults)
	{
		// Enable the necessary events
		this.enableEvents(AWTEvent.KEY_EVENT_MASK);

		// Initialize some misc. stuff
		this.painter = new TextAreaPainter(this,defaults);
		
		this.documentHandler = new DocumentHandler();
		this.listenerList = new EventListenerList();
		this.caretEvent = new MutableCaretEvent();
		this.lineSegment = new Segment();
		this.bracketLine = this.bracketPosition = -1;

		this.blink = true;

		//undoredo_tool = new UndoRedoText(this);

		// Initialize the GUI
		this.setLayout(new ScrollLayout());
		this.add(CENTER,this.painter);
		this.add(RIGHT,this.vertical = new JScrollBar(Adjustable.VERTICAL));
		this.add(BOTTOM,this.horizontal = new JScrollBar(Adjustable.HORIZONTAL));

		// Add some event listeners
		this.vertical.addAdjustmentListener(new AdjustHandler());
		this.horizontal.addAdjustmentListener(new AdjustHandler());
		this.painter.addComponentListener(new ComponentHandler());
		this.painter.addMouseListener(new MouseHandler());
		this.painter.addMouseMotionListener(new DragHandler());
		this.painter.addMouseMotionListener( this );
		this.addFocusListener(new FocusHandler());

		// Load the defaults
		this.setInputHandler(defaults.inputHandler);
		this.setDocument(defaults.document);
		this.editable = defaults.editable;
		this.caretVisible = defaults.caretVisible;
		this.caretBlinks = defaults.caretBlinks;
		this.electricScroll = defaults.electricScroll;

		this.popup = defaults.popup;

		this.popupInfo = new PopupInfoBox();

		// We don't seem to get the initial focus event?
		focusedComponent = this;

		this.addMouseWheelListener(new MouseWheelListener() {
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				if (JCodeTextArea.this.scrollBarsInitialized) {
					if (e.getScrollType() == MouseWheelEvent.WHEEL_UNIT_SCROLL) {
						int amt = e.getUnitsToScroll();
						JCodeTextArea.this.vertical.setValue(JCodeTextArea.this.vertical.getValue() + amt);
					}
				}
			}
		});

		this.document.addUndoableEditListener(
				new UndoableEditListener() {
					@Override
					public void undoableEditHappened(UndoableEditEvent e) {
						JCodeTextArea.this.undoManager.addEdit(e.getEdit());
					}
				});
	}

	/**
	 * Returns if this component can be traversed by pressing
	 * the Tab key. This returns false.
	 */
	@Override
	public final boolean isManagingFocus()
	{
		return true;
	}

	/**
	 * Returns the object responsible for painting this text area.
	 */
	public final TextAreaPainter getPainter()
	{
		return this.painter;
	}

	/**
	 * Returns the input handler.
	 */
	public final InputHandler getInputHandler()
	{
		return this.inputHandler;
	}

	/**
	 * Sets the input handler.
	 * @param inputHandler The new input handler
	 */
	public void setInputHandler(InputHandler inputHandler)
	{
		this.inputHandler = inputHandler;
	}

	/**
	 * Returns true if the caret is blinking, false otherwise.
	 */
	public final boolean isCaretBlinkEnabled()
	{
		return this.caretBlinks;
	}

	/**
	 * Toggles caret blinking.
	 * @param caretBlinks True if the caret should blink, false otherwise
	 */
	public void setCaretBlinkEnabled(boolean caretBlinks)
	{
		this.caretBlinks = caretBlinks;
		if(!caretBlinks)
			this.blink = false;

		this.painter.invalidateSelectedLines();
	}

	/**
	 * Returns true if the caret is visible, false otherwise.
	 */
	public final boolean isCaretVisible()
	{
		return (!this.caretBlinks || this.blink) && this.caretVisible;
	}

	/**
	 * Sets if the caret should be visible.
	 * @param caretVisible True if the caret should be visible, false
	 * otherwise
	 */
	public void setCaretVisible(boolean caretVisible)
	{
		this.caretVisible = caretVisible;
		this.blink = true;

		this.painter.invalidateSelectedLines();
	}

	/**
	 * Blinks the caret.
	 */
	public final void blinkCaret()
	{
		if(this.caretBlinks)
		{
			this.blink = !this.blink;
			this.painter.invalidateSelectedLines();
		}
		else
			this.blink = true;
	}

	/**
	 * Returns the number of lines from the top and button of the
	 * text area that are always visible.
	 */
	public final int getElectricScroll()
	{
		return this.electricScroll;
	}

	/**
	 * Sets the number of lines from the top and bottom of the text
	 * area that are always visible
	 * @param electricScroll The number of lines always visible from
	 * the top or bottom
	 */
	public final void setElectricScroll(int electricScroll)
	{
		this.electricScroll = electricScroll;
	}

	/**
	 * Updates the state of the scroll bars. This should be called
	 * if the number of lines in the document changes, or when the
	 * size of the text are changes.
	 */
	public void updateScrollBars()
	{
		if(this.vertical != null && this.visibleLines != 0)
		{
			this.vertical.setValues(this.firstLine,this.visibleLines,0,this.getLineCount());
			this.vertical.setUnitIncrement(2);
			this.vertical.setBlockIncrement(this.visibleLines);
		}

		int width = this.painter.getWidth();
		if(this.horizontal != null && width != 0)
		{
			this.horizontal.setValues(-this.horizontalOffset,width,0,width * 5);
			this.horizontal.setUnitIncrement(this.painter.getFontMetrics()
					.charWidth('w'));
			this.horizontal.setBlockIncrement(width / 2);
		}
	}

	/**
	 * Returns the line displayed at the text area's origin.
	 */
	public final int getFirstLine()
	{
		return this.firstLine;
	}

	/**
	 * Sets the line displayed at the text area's origin without
	 * updating the scroll bars.
	 */
	public void setFirstLine(int firstLine)
	{
		if(firstLine == this.firstLine)
			return;
		this.firstLine = firstLine;
		if(firstLine != this.vertical.getValue())
			this.updateScrollBars();
		this.painter.repaint();
	}

	/**
	 * Returns the number of lines visible in this text area.
	 */
	public final int getVisibleLines()
	{
		return this.visibleLines;
	}

	/**
	 * Recalculates the number of visible lines. This should not
	 * be called directly.
	 */
	public final void recalculateVisibleLines()
	{
		if(this.painter == null)
			return;
		int height = this.painter.getHeight();
		int lineHeight = this.painter.getFontMetrics().getHeight();
		this.visibleLines = height / lineHeight;
		this.updateScrollBars();
	}

	/**
	 * Returns the horizontal offset of drawn lines.
	 */
	public final int getHorizontalOffset()
	{
		return this.horizontalOffset;
	}

	/**
	 * Sets the horizontal offset of drawn lines. This can be used to
	 * implement horizontal scrolling.
	 * @param horizontalOffset offset The new horizontal offset
	 */
	public void setHorizontalOffset(int horizontalOffset)
	{
		if(horizontalOffset == this.horizontalOffset)
			return;
		this.horizontalOffset = horizontalOffset;
		if(horizontalOffset != this.horizontal.getValue())
			this.updateScrollBars();
		this.painter.repaint();
	}

	/**
	 * A fast way of changing both the first line and horizontal
	 * offset.
	 * @param firstLine The new first line
	 * @param horizontalOffset The new horizontal offset
	 * @return True if any of the values were changed, false otherwise
	 */
	public boolean setOrigin(int firstLine, int horizontalOffset)
	{
		boolean changed = false;
		if(horizontalOffset != this.horizontalOffset)
		{
			this.horizontalOffset = horizontalOffset;
			changed = true;
		}

		if(firstLine != this.firstLine)
		{
			this.firstLine = firstLine;
			changed = true;
		}

		if(changed)
		{
			this.updateScrollBars();
			this.painter.repaint();
		}

		return changed;
	}

	/**
	 * Ensures that the caret is visible by scrolling the text area if
	 * necessary.
	 * @return True if scrolling was actually performed, false if the
	 * caret was already visible
	 */
	public boolean scrollToCaret()
	{
		int line = this.getCaretLine();
		int lineStart = this.getLineStartOffset(line);
		int offset = Math.max(0,Math.min(this.getLineLength(line) - 1,
				this.getCaretPosition() - lineStart));

		return this.scrollTo(line,offset);
	}

	/**
	 * Ensures that the specified line and offset is visible by scrolling
	 * the text area if necessary.
	 * @param line The line to scroll to
	 * @param offset The offset in the line to scroll to
	 * @return True if scrolling was actually performed, false if the
	 * line and offset was already visible
	 */
	public boolean scrollTo(int line, int offset)
	{
		// visibleLines == 0 before the component is realized
		// we can't do any proper scrolling then, so we have
		// this hack...
		if(this.visibleLines == 0)
		{
			this.setFirstLine(Math.max(0,line - this.electricScroll));
			return true;
		}

		int newFirstLine = this.firstLine;
		int newHorizontalOffset = this.horizontalOffset;

		if(line < this.firstLine + this.electricScroll)
		{
			newFirstLine = Math.max(0,line - this.electricScroll);
		}
		else if(line + this.electricScroll >= this.firstLine + this.visibleLines)
		{
			newFirstLine = (line - this.visibleLines) + this.electricScroll + 1;
			if(newFirstLine + this.visibleLines >= this.getLineCount())
				newFirstLine = this.getLineCount() - this.visibleLines;
			if(newFirstLine < 0)
				newFirstLine = 0;
		}

		int x = this._offsetToX(line,offset);
		int width = this.painter.getFontMetrics().charWidth('w');

		if(x < 0)
		{
			newHorizontalOffset = Math.min(0,this.horizontalOffset
					- x + width + 5);
		}
		else if(x + width >= this.painter.getWidth())
		{
			newHorizontalOffset = this.horizontalOffset +
					(this.painter.getWidth() - x) - width - 5;
		}

		return this.setOrigin(newFirstLine,newHorizontalOffset);
	}

	/**
	 * Converts a line index to a y co-ordinate.
	 * @param line The line
	 */
	public int lineToY(int line)
	{
		FontMetrics fm = this.painter.getFontMetrics();
		return (line - this.firstLine) * fm.getHeight()
				- (fm.getLeading() + fm.getMaxDescent());
	}

	/**
	 * Converts a y co-ordinate to a line index.
	 * @param y The y co-ordinate
	 */
	public int yToLine(int y)
	{
		FontMetrics fm = this.painter.getFontMetrics();
		int height = fm.getHeight();
		return Math.max(0,Math.min(this.getLineCount() - 1,
				y / height + this.firstLine));
	}

	/**
	 * Converts an offset in a line into an x co-ordinate. This is a
	 * slow version that can be used any time.
	 * @param line The line
	 * @param offset The offset, from the start of the line
	 */
	public final int offsetToX(int line, int offset)
	{
		// don't use cached tokens
		this.painter.currentLineTokens = null;
		return this._offsetToX(line,offset);
	}

	/**
	 * Converts an offset in a line into an x co-ordinate. This is a
	 * fast version that should only be used if no changes were made
	 * to the text since the last repaint.
	 * @param line The line
	 * @param offset The offset, from the start of the line
	 */
	public int _offsetToX(int line, int offset)
	{
		SyntaxTokenMarker tokenMarker = this.getTokenMarker();

		/* Use painter's cached info for speed */
		FontMetrics fm = this.painter.getFontMetrics();

		this.getLineText(line,this.lineSegment);

		int segmentOffset = this.lineSegment.offset;
		int x = this.horizontalOffset;

		/* If syntax coloring is disabled, do simple translation */
		if(tokenMarker == null)
		{
			this.lineSegment.count = offset;
			return x + Utilities.getTabbedTextWidth(this.lineSegment,
					fm,x,this.painter,0);
		}
		/* If syntax coloring is enabled, we have to do this because
		 * tokens can vary in width */
		else
		{
			SyntaxToken tokens;
			if(this.painter.currentLineIndex == line
					&& this.painter.currentLineTokens != null)
				tokens = this.painter.currentLineTokens;
			else
			{
				this.painter.currentLineIndex = line;
				tokens = this.painter.currentLineTokens
						= tokenMarker.markTokens(this.lineSegment,line);
			}

			this.painter.getToolkit();
			Font defaultFont = this.painter.getFont();
			SyntaxStyle[] styles = this.painter.getStyles();

			for(;;)
			{
				byte id = tokens.id;
				if(id == SyntaxToken.END)
				{
					return x;
				}

				if(id == SyntaxToken.NULL)
					fm = this.painter.getFontMetrics();
				else
					fm = styles[id].getFontMetrics(defaultFont);

				int length = tokens.length;

				if(offset + segmentOffset < this.lineSegment.offset + length)
				{
					this.lineSegment.count = offset - (this.lineSegment.offset - segmentOffset);
					return x + Utilities.getTabbedTextWidth(
							this.lineSegment,fm,x,this.painter,0);
				}
				else
				{
					this.lineSegment.count = length;
					x += Utilities.getTabbedTextWidth(
							this.lineSegment,fm,x,this.painter,0);
					this.lineSegment.offset += length;
				}
				tokens = tokens.next;
			}
		}
	}

	/**
	 * Converts an x co-ordinate to an offset within a line.
	 * @param line The line
	 * @param x The x co-ordinate
	 */
	public int xToOffset(int line, int x)
	{
		SyntaxTokenMarker tokenMarker = this.getTokenMarker();

		/* Use painter's cached info for speed */
		FontMetrics fm = this.painter.getFontMetrics();

		this.getLineText(line,this.lineSegment);

		char[] segmentArray = this.lineSegment.array;
		int segmentOffset = this.lineSegment.offset;
		int segmentCount = this.lineSegment.count;

		int width = this.horizontalOffset;

		if(tokenMarker == null)
		{
			for(int i = 0; i < segmentCount; i++)
			{
				char c = segmentArray[i + segmentOffset];
				int charWidth;
				if(c == '\t')
					charWidth = (int)this.painter.nextTabStop(width,i)
					- width;
				else
					charWidth = fm.charWidth(c);

				if(this.painter.isBlockCaretEnabled())
				{
					if(x - charWidth <= width)
						return i;
				}
				else
				{
					if(x - charWidth / 2 <= width)
						return i;
				}

				width += charWidth;
			}

			return segmentCount;
		}
		else
		{
			SyntaxToken tokens;
			if(this.painter.currentLineIndex == line && this.painter
					.currentLineTokens != null)
				tokens = this.painter.currentLineTokens;
			else
			{
				this.painter.currentLineIndex = line;
				tokens = this.painter.currentLineTokens
						= tokenMarker.markTokens(this.lineSegment,line);
			}

			int offset = 0;
			this.painter.getToolkit();
			Font defaultFont = this.painter.getFont();
			SyntaxStyle[] styles = this.painter.getStyles();

			for(;;)
			{
				byte id = tokens.id;
				if(id == SyntaxToken.END)
					return offset;

				if(id == SyntaxToken.NULL)
					fm = this.painter.getFontMetrics();
				else
					fm = styles[id].getFontMetrics(defaultFont);

				int length = tokens.length;

				for(int i = 0; i < length; i++)
				{
					char c = segmentArray[segmentOffset + offset + i];
					int charWidth;
					if(c == '\t')
						charWidth = (int)this.painter.nextTabStop(width,offset + i)
						- width;
					else
						charWidth = fm.charWidth(c);

					if(this.painter.isBlockCaretEnabled())
					{
						if(x - charWidth <= width)
							return offset + i;
					}
					else
					{
						if(x - charWidth / 2 <= width)
							return offset + i;
					}

					width += charWidth;
				}

				offset += length;
				tokens = tokens.next;
			}
		}
	}

	/**
	 * Converts a point to an offset, from the start of the text.
	 * @param x The x co-ordinate of the point
	 * @param y The y co-ordinate of the point
	 */
	public int xyToOffset(int x, int y)
	{
		int line = this.yToLine(y);
		int start = this.getLineStartOffset(line);
		return start + this.xToOffset(line,x);
	}

	/**
	 * Returns the document this text area is editing.
	 */
	public final SyntaxDocument getDocument()
	{
		return this.document;
	}

	/**
	 * Sets the document this text area is editing.
	 * @param document The document
	 */
	public void setDocument(SyntaxDocument document)
	{
		if(this.document == document)
			return;
		if(this.document != null)
			this.document.removeDocumentListener(this.documentHandler);
		this.document = document;

		document.addDocumentListener(this.documentHandler);

		this.select(0,0);
		this.updateScrollBars();
		this.painter.repaint();
	}

	/**
	 * Returns the document's token marker. Equivalent to calling
	 * <code>getDocument().getTokenMarker()</code>.
	 */
	public final SyntaxTokenMarker getTokenMarker()
	{
		return this.document.getTokenMarker();
	}

	/**
	 * Sets the document's token marker. Equivalent to caling
	 * <code>getDocument().setTokenMarker()</code>.
	 * @param tokenMarker The token marker
	 */
	public final void setTokenMarker(SyntaxTokenMarker tokenMarker)
	{
		this.document.setTokenMarker(tokenMarker);
	}

	/**
	 * Returns the length of the document. Equivalent to calling
	 * <code>getDocument().getLength()</code>.
	 */
	public final int getDocumentLength()
	{
		return this.document.getLength();
	}

	/**
	 * Returns the number of lines in the document.
	 */
	public final int getLineCount()
	{
		return this.document.getDefaultRootElement().getElementCount();
	}

	/**
	 * Returns the line containing the specified offset.
	 * @param offset The offset
	 */
	public final int getLineOfOffset(int offset)
	{
		return this.document.getDefaultRootElement().getElementIndex(offset);
	}

	/**
	 * Returns the start offset of the specified line.
	 * @param line The line
	 * @return The start offset of the specified line, or -1 if the line is
	 * invalid
	 */
	public int getLineStartOffset(int line)
	{
		Element lineElement = this.document.getDefaultRootElement()
				.getElement(line);
		if(lineElement == null)
			return -1;
		else
			return lineElement.getStartOffset();
	}

	/**
	 * Returns the end offset of the specified line.
	 * @param line The line
	 * @return The end offset of the specified line, or -1 if the line is
	 * invalid.
	 */
	public int getLineEndOffset(int line)
	{
		Element lineElement = this.document.getDefaultRootElement()
				.getElement(line);
		if(lineElement == null)
			return -1;
		else
			return lineElement.getEndOffset();
	}

	/**
	 * Returns the length of the specified line.
	 * @param line The line
	 */
	public int getLineLength(int line)
	{
		Element lineElement = this.document.getDefaultRootElement()
				.getElement(line);
		if(lineElement == null)
			return -1;
		else
			return lineElement.getEndOffset()
					- lineElement.getStartOffset() - 1;
	}

	/**
	 * Returns the entire text of this text area.
	 */
	public String getText()
	{
		try
		{
			return this.document.getText(0,this.document.getLength());
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
			return null;
		}
	}

	/**
	 * Sets the entire text of this text area and init undo stack;
	 */
	public void initText(String text)
	{
		try
		{
			this.document.beginCompoundEdit();
			this.document.remove(0,this.document.getLength());
			this.document.insertString(0,text,null);
			this.undoManager.discardAllEdits();
			//undoredo_tool.modified();
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
		}
		finally
		{
			this.document.endCompoundEdit();
		}
	}
	/**
	 * Sets the entire text of this text area.
	 */
	public void setText(String text)
	{
		try
		{
			this.document.beginCompoundEdit();
			this.document.remove(0,this.document.getLength());
			this.document.insertString(0,text,null);
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
		}
		finally
		{
			this.document.endCompoundEdit();
		}
	}

	/**
	 * Returns the specified substring of the document.
	 * @param start The start offset
	 * @param len The length of the substring
	 * @return The substring, or null if the offsets are invalid
	 */
	public final String getText(int start, int len)
	{
		try
		{
			return this.document.getText(start,len);
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
			return null;
		}
	}

	/**
	 * Copies the specified substring of the document into a segment.
	 * If the offsets are invalid, the segment will contain a null string.
	 * @param start The start offset
	 * @param len The length of the substring
	 * @param segment The segment
	 */
	public final void getText(int start, int len, Segment segment)
	{
		try
		{
			this.document.getText(start,len,segment);
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
			segment.offset = segment.count = 0;
		}
	}

	/**
	 * Returns the text on the specified line.
	 * @param lineIndex The line
	 * @return The text, or null if the line is invalid
	 */
	public final String getLineText(int lineIndex)
	{
		int start = this.getLineStartOffset(lineIndex);
		return this.getText(start,this.getLineEndOffset(lineIndex) - start - 1);
	}

	/**
	 * Copies the text on the specified line into a segment. If the line
	 * is invalid, the segment will contain a null string.
	 * @param lineIndex The line
	 */
	public final void getLineText(int lineIndex, Segment segment)
	{
		int start = this.getLineStartOffset(lineIndex);
		this.getText(start,this.getLineEndOffset(lineIndex) - start - 1,segment);
	}

	/**
	 * Returns the selection start offset.
	 */
	public final int getSelectionStart()
	{
		return this.selectionStart;
	}

	/**
	 * Returns the offset where the selection starts on the specified
	 * line.
	 */
	public int getSelectionStart(int line)
	{
		if(line == this.selectionStartLine)
			return this.selectionStart;
		else if(this.rectSelect)
		{
			Element map = this.document.getDefaultRootElement();
			int start = this.selectionStart - map.getElement(this.selectionStartLine)
					.getStartOffset();

			Element lineElement = map.getElement(line);
			int lineStart = lineElement.getStartOffset();
			int lineEnd = lineElement.getEndOffset() - 1;
			return Math.min(lineEnd,lineStart + start);
		}
		else
			return this.getLineStartOffset(line);
	}

	/**
	 * Returns the selection start line.
	 */
	public final int getSelectionStartLine()
	{
		return this.selectionStartLine;
	}

	/**
	 * Sets the selection start. The new selection will be the new
	 * selection start and the old selection end.
	 * @param selectionStart The selection start
	 * @see #select(int,int)
	 */
	public final void setSelectionStart(int selectionStart)
	{
		this.select(selectionStart,this.selectionEnd);
	}

	/**
	 * Returns the selection end offset.
	 */
	public final int getSelectionEnd()
	{
		return this.selectionEnd;
	}

	/**
	 * Returns the offset where the selection ends on the specified
	 * line.
	 */
	public int getSelectionEnd(int line)
	{
		if(line == this.selectionEndLine)
			return this.selectionEnd;
		else if(this.rectSelect)
		{
			Element map = this.document.getDefaultRootElement();
			int end = this.selectionEnd - map.getElement(this.selectionEndLine)
					.getStartOffset();

			Element lineElement = map.getElement(line);
			int lineStart = lineElement.getStartOffset();
			int lineEnd = lineElement.getEndOffset() - 1;
			return Math.min(lineEnd,lineStart + end);
		}
		else
			return this.getLineEndOffset(line) - 1;
	}

	/**
	 * Returns the selection end line.
	 */
	public final int getSelectionEndLine()
	{
		return this.selectionEndLine;
	}

	/**
	 * Sets the selection end. The new selection will be the old
	 * selection start and the bew selection end.
	 * @param selectionEnd The selection end
	 * @see #select(int,int)
	 */
	public final void setSelectionEnd(int selectionEnd)
	{
		this.select(this.selectionStart,selectionEnd);
	}

	/**
	 * Returns the caret position. This will either be the selection
	 * start or the selection end, depending on which direction the
	 * selection was made in.
	 */
	public final int getCaretPosition()
	{
		return (this.biasLeft ? this.selectionStart : this.selectionEnd);
	}

	/**
	 * Returns the caret line.
	 */
	public final int getCaretLine()
	{
		return (this.biasLeft ? this.selectionStartLine : this.selectionEndLine);
	}

	/**
	 * Returns the mark position. This will be the opposite selection
	 * bound to the caret position.
	 * @see #getCaretPosition()
	 */
	public final int getMarkPosition()
	{
		return (this.biasLeft ? this.selectionEnd : this.selectionStart);
	}

	/**
	 * Returns the mark line.
	 */
	public final int getMarkLine()
	{
		return (this.biasLeft ? this.selectionEndLine : this.selectionStartLine);
	}

	/**
	 * Sets the caret position. The new selection will consist of the
	 * caret position only (hence no text will be selected)
	 * @param caret The caret position
	 * @see #select(int,int)
	 */
	public final void setCaretPosition(int caret)
	{
		this.select(caret,caret);
	}

	/**
	 * Selects all text in the document.
	 */
	public final void selectAll()
	{
		this.select(0,this.getDocumentLength());
	}

	/**
	 * Moves the mark to the caret position.
	 */
	public final void selectNone()
	{
		this.select(this.getCaretPosition(),this.getCaretPosition());
	}

	protected CaretUndo undoer;

	/**
	 * Selects from the start offset to the end offset. This is the
	 * general selection method used by all other selecting methods.
	 * The caret position will be start if start &lt; end, and end
	 * if end &gt; start.
	 * @param start The start offset
	 * @param end The end offset
	 */
	public void select(int start, int end)
	{
		int newStart, newEnd;
		boolean newBias;
		if(start <= end)
		{
			newStart = start;
			newEnd = end;
			newBias = false;
		}
		else
		{
			newStart = end;
			newEnd = start;
			newBias = true;
		}

		if(newStart < 0 || newEnd > this.getDocumentLength())
		{
			throw new IllegalArgumentException("Bounds out of"
					+ " range: " + newStart + "," +
					newEnd);
		}

		// If the new position is the same as the old, we don't
		// do all this crap, however we still do the stuff at
		// the end (clearing magic position, scrolling)
		if(newStart != this.selectionStart || newEnd != this.selectionEnd
				|| newBias != this.biasLeft)
		{
			int newStartLine = this.getLineOfOffset(newStart);
			int newEndLine = this.getLineOfOffset(newEnd);

			if(this.painter.isBracketHighlightEnabled())
			{
				if(this.bracketLine != -1)
					this.painter.invalidateLine(this.bracketLine);
				this.updateBracketHighlight(end);
				if(this.bracketLine != -1)
					this.painter.invalidateLine(this.bracketLine);
			}

			this.painter.invalidateLineRange(this.selectionStartLine,this.selectionEndLine);
			this.painter.invalidateLineRange(newStartLine,newEndLine);

			this.document.addUndoableEdit(this.undoer = new CaretUndo(
					this.selectionStart,this.selectionEnd));

			this.selectionStart = newStart;
			this.selectionEnd = newEnd;
			this.selectionStartLine = newStartLine;
			this.selectionEndLine = newEndLine;
			this.biasLeft = newBias;

			this.fireCaretEvent();
		}

		// When the user is typing, etc, we don't want the caret
		// to blink
		this.blink = true;
		caretTimer.restart();

		// Disable rectangle select if selection start = selection end
		if(this.selectionStart == this.selectionEnd)
			this.rectSelect = false;

		// Clear the `magic' caret position used by up/down
		this.magicCaret = -1;

		this.scrollToCaret();
	}

	/**
	 * Returns the selected text, or null if no selection is active.
	 */
	public final String getSelectedText()
	{
		if(this.selectionStart == this.selectionEnd)
			return null;

		if(this.rectSelect)
		{
			// Return each row of the selection on a new line

			Element map = this.document.getDefaultRootElement();

			int start = this.selectionStart - map.getElement(this.selectionStartLine)
					.getStartOffset();
			int end = this.selectionEnd - map.getElement(this.selectionEndLine)
					.getStartOffset();

			// Certain rectangles satisfy this condition...
			if(end < start)
			{
				int tmp = end;
				end = start;
				start = tmp;
			}

			StringBuffer buf = new StringBuffer();
			Segment seg = new Segment();

			for(int i = this.selectionStartLine; i <= this.selectionEndLine; i++)
			{
				Element lineElement = map.getElement(i);
				int lineStart = lineElement.getStartOffset();
				int lineEnd = lineElement.getEndOffset() - 1;
				int lineLen = lineEnd - lineStart;

				lineStart = Math.min(lineStart + start,lineEnd);
				lineLen = Math.min(end - start,lineEnd - lineStart);

				this.getText(lineStart,lineLen,seg);
				buf.append(seg.array,seg.offset,seg.count);

				if(i != this.selectionEndLine)
					buf.append('\n');
			}

			return buf.toString();
		}
		else
		{
			return this.getText(this.selectionStart,
					this.selectionEnd - this.selectionStart);
		}
	}

	/**
	 * Replaces the selection with the specified text.
	 * @param selectedText The replacement text for the selection
	 */
	public void setSelectedText(String selectedText)
	{
		if(!this.editable)
		{
			throw new InternalError("Text component"
					+ " read only");
		}

		this.document.beginCompoundEdit();

		try
		{
			if(this.rectSelect)
			{
				Element map = this.document.getDefaultRootElement();

				int start = this.selectionStart - map.getElement(this.selectionStartLine)
						.getStartOffset();
				int end = this.selectionEnd - map.getElement(this.selectionEndLine)
						.getStartOffset();

				// Certain rectangles satisfy this condition...
				if(end < start)
				{
					int tmp = end;
					end = start;
					start = tmp;
				}

				int lastNewline = 0;
				int currNewline = 0;

				for(int i = this.selectionStartLine; i <= this.selectionEndLine; i++)
				{
					Element lineElement = map.getElement(i);
					int lineStart = lineElement.getStartOffset();
					int lineEnd = lineElement.getEndOffset() - 1;
					int rectStart = Math.min(lineEnd,lineStart + start);

					this.document.remove(rectStart,Math.min(lineEnd - rectStart,
							end - start));

					if(selectedText == null)
						continue;

					currNewline = selectedText.indexOf('\n',lastNewline);
					if(currNewline == -1)
						currNewline = selectedText.length();

					this.document.insertString(rectStart,selectedText
							.substring(lastNewline,currNewline),null);

					lastNewline = Math.min(selectedText.length(),
							currNewline + 1);
				}

				if(selectedText != null &&
						currNewline != selectedText.length())
				{
					int offset = map.getElement(this.selectionEndLine)
							.getEndOffset() - 1;
					this.document.insertString(offset,"\n",null);
					this.document.insertString(offset + 1,selectedText
							.substring(currNewline + 1),null);
				}
			}
			else
			{
				this.document.remove(this.selectionStart,
						this.selectionEnd - this.selectionStart);
				if(selectedText != null)
				{
					this.document.insertString(this.selectionStart,
							selectedText,null);
				}
			}
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
			throw new InternalError("Cannot replace"
					+ " selection");
		}
		// No matter what happends... stops us from leaving document
		// in a bad state
		finally
		{
			this.document.endCompoundEdit();
		}

		this.setCaretPosition(this.selectionEnd);
	}

	/**
	 * Returns true if this text area is editable, false otherwise.
	 */
	public final boolean isEditable()
	{
		return this.editable;
	}

	/**
	 * Sets if this component is editable.
	 * @param editable True if this text area should be editable,
	 * false otherwise
	 */
	public final void setEditable(boolean editable)
	{
		this.editable = editable;
	}

	/**
	 * Returns the right click popup menu.
	 */
	public final JPopupMenu getRightClickPopup()
	{
		return this.popup;
	}

	/**
	 * Sets the right click popup menu.
	 * @param popup The popup
	 */
	public final void setRightClickPopup(JPopupMenu popup)
	{
		this.popup = popup;
	}

	/**
	 * Returns the `magic' caret position. This can be used to preserve
	 * the column position when moving up and down lines.
	 */
	public final int getMagicCaretPosition()
	{
		return this.magicCaret;
	}

	/**
	 * Sets the `magic' caret position. This can be used to preserve
	 * the column position when moving up and down lines.
	 * @param magicCaret The magic caret position
	 */
	public final void setMagicCaretPosition(int magicCaret)
	{
		this.magicCaret = magicCaret;
	}

	/**
	 * Similar to <code>setSelectedText()</code>, but overstrikes the
	 * appropriate number of characters if overwrite mode is enabled.
	 * @param str The string
	 * @see #setSelectedText(String)
	 * @see #isOverwriteEnabled()
	 */
	public void overwriteSetSelectedText(String str)
	{
		// Don't overstrike if there is a selection
		if(!this.overwrite || this.selectionStart != this.selectionEnd)
		{
			this.setSelectedText(str);
			return;
		}

		// Don't overstrike if we're on the end of
		// the line
		int caret = this.getCaretPosition();
		int caretLineEnd = this.getLineEndOffset(this.getCaretLine());
		if(caretLineEnd - caret <= str.length())
		{
			this.setSelectedText(str);
			return;
		}

		this.document.beginCompoundEdit();

		try
		{
			this.document.remove(caret,str.length());
			this.document.insertString(caret,str,null);
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
		}
		finally
		{
			this.document.endCompoundEdit();
		}
	}

	/**
	 * Returns true if overwrite mode is enabled, false otherwise.
	 */
	public final boolean isOverwriteEnabled()
	{
		return this.overwrite;
	}

	/**
	 * Sets if overwrite mode should be enabled.
	 * @param overwrite True if overwrite mode should be enabled,
	 * false otherwise.
	 */
	public final void setOverwriteEnabled(boolean overwrite)
	{
		this.overwrite = overwrite;
		this.painter.invalidateSelectedLines();
	}

	/**
	 * Returns true if the selection is rectangular, false otherwise.
	 */
	public final boolean isSelectionRectangular()
	{
		return this.rectSelect;
	}

	/**
	 * Sets if the selection should be rectangular.
	 * @param overwrite True if the selection should be rectangular,
	 * false otherwise.
	 */
	public final void setSelectionRectangular(boolean rectSelect)
	{
		this.rectSelect = rectSelect;
		this.painter.invalidateSelectedLines();
	}

	/**
	 * Returns the position of the highlighted bracket (the bracket
	 * matching the one before the caret)
	 */
	public final int getBracketPosition()
	{
		return this.bracketPosition;
	}

	/**
	 * Returns the line of the highlighted bracket (the bracket
	 * matching the one before the caret)
	 */
	public final int getBracketLine()
	{
		return this.bracketLine;
	}

	/**
	 * Adds a caret change listener to this text area.
	 * @param listener The listener
	 */
	public final void addCaretListener(CaretListener listener)
	{
		this.listenerList.add(CaretListener.class,listener);
	}

	/**
	 * Removes a caret change listener from this text area.
	 * @param listener The listener
	 */
	public final void removeCaretListener(CaretListener listener)
	{
		this.listenerList.remove(CaretListener.class,listener);
	}

	/**
	 * Deletes the selected text from the text area and places it
	 * into the clipboard.
	 */
	public void cut()
	{
		if(this.editable)
		{
			this.copy();
			this.setSelectedText("");
		}
	}

	/**
	 * Places the selected text into the clipboard.
	 */
	public void copy()
	{
		if(this.selectionStart != this.selectionEnd)
		{
			Clipboard clipboard = this.getToolkit().getSystemClipboard();

			String selection = this.getSelectedText();

			int repeatCount = this.inputHandler.getRepeatCount();
			StringBuffer buf = new StringBuffer();
			for(int i = 0; i < repeatCount; i++)
				buf.append(selection);

			clipboard.setContents(new StringSelection(buf.toString()),null);
		}
	}

	/**
	 * Inserts the clipboard contents into the text.
	 */
	public void paste()
	{
		if(this.editable)
		{
			Clipboard clipboard = this.getToolkit().getSystemClipboard();
			try
			{
				// The MacOS MRJ doesn't convert \r to \n,
				// so do it here
				String selection = ((String)clipboard
						.getContents(this).getTransferData(
								DataFlavor.stringFlavor))
						.replace('\r','\n');

				int repeatCount = this.inputHandler.getRepeatCount();
				StringBuffer buf = new StringBuffer();
				for(int i = 0; i < repeatCount; i++)
					buf.append(selection);
				selection = buf.toString();
				this.setSelectedText(selection);
			}
			catch(Exception e)
			{
				this.getToolkit().beep();
				System.err.println("Clipboard does not"
						+ " contain a string");
			}
		}
	}

	/**
	 * Called by the AWT when this component is removed from it's parent.
	 * This stops clears the currently focused component.
	 */
	@Override
	public void removeNotify()
	{
		super.removeNotify();
		if(focusedComponent == this)
			focusedComponent = null;
	}

	/**
	 * Forwards key events directly to the input handler.
	 * This is slightly faster than using a KeyListener
	 * because some Swing overhead is avoided.
	 */
	@Override
	public void processKeyEvent(KeyEvent evt)
	{


		if(this.inputHandler == null)
			return;
		switch(evt.getID())
		{
		case KeyEvent.KEY_TYPED:

			if (evt.getKeyChar()=='\t'){
				if (selectionStartLine != selectionEndLine)
					return;
			}
			
			if (! (evt.getKeyChar()==' ' && evt.isControlDown())){		
				if (!SuggestionPanel.keyTyped(this, evt))
					this.inputHandler.keyTyped(evt);
			}
			//if (!evt.isControlDown())
			//undoredo_tool.modified();
			break;
		case KeyEvent.KEY_PRESSED:

			if (evt.getKeyCode()==KeyEvent.VK_TAB)
				if (selectionStartLine != selectionEndLine){
					for(int i=selectionEndLine;i>=selectionStartLine;--i)
						if (evt.isShiftDown()){
							try {
								int index = getLineStartOffset(i);
								if (getLineText(i).startsWith("\t"))
									document.remove(index, 1);
								else if (getLineText(i).startsWith("     "))
									document.remove(index, 5);
								else if (getLineText(i).startsWith("    "))
									document.remove(index, 4);
								else if (getLineText(i).startsWith("   "))
									document.remove(index, 3);
								else if (getLineText(i).startsWith("  "))
									document.remove(index, 2);
								else if (getLineText(i).startsWith(" "))
									document.remove(index, 1);								
							} catch (BadLocationException e) {}
							
						}else{
							try {
								int index = getLineStartOffset(i);
								this.document.insertString(index,"\t",null);
							} catch (BadLocationException e) {}
						}
					return;
				}
			
			if (evt.getKeyCode()==KeyEvent.VK_O && evt.isControlDown()){
				MainMenu.loadFile();
			}else if (evt.getKeyCode()==KeyEvent.VK_S && evt.isControlDown()){
				MainEditor.saveFile(this);
			}else if (evt.getKeyCode()==KeyEvent.VK_B && evt.isControlDown()){
				MainEditor.compileShader(this,true);
			}else if (evt.getKeyCode()==KeyEvent.VK_SPACE && evt.isControlDown()){

				SuggestionPanel.showSuggestionLater(this);
			}else if (evt.getKeyCode()==KeyEvent.VK_ESCAPE && SuggestionPanel.isVisible()){
				SuggestionPanel.hideSuggestion();
			}else if (evt.getKeyCode()==90 && evt.isControlDown())
				//undoredo_tool.undo();
				try{ this.undoManager.undo(); } catch (Exception e){}
			else if (evt.getKeyCode()==89 && evt.isControlDown())
				try{ this.undoManager.redo(); } catch (Exception e){}
			//undoredo_tool.redo();
			else{
				if (!(SuggestionPanel.isVisible() && (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN) ) )
					this.inputHandler.keyPressed(evt);
			}


			break;
		case KeyEvent.KEY_RELEASED:

			if (evt.getKeyCode()==KeyEvent.VK_TAB)
				if (selectionStartLine != selectionEndLine)
					return;
			
			if ((evt.getKeyCode()==KeyEvent.VK_SPACE && evt.isControlDown()) || (!SuggestionPanel.keyReleased(this, evt)))
				this.inputHandler.keyReleased(evt);
			
			if (evt.getKeyCode() == KeyEvent.VK_ENTER && !SuggestionPanel.isVisible()){
				try {
					int line = this.getCaretLine();
					String previousLine = this.getLineText(line-1);
					String currentLine = this.getLineText(line);
					int i=0;
					String insert = ""; 
					while (i<previousLine.length() && (previousLine.charAt(i)==' ' || previousLine.charAt(i)=='\t')){
						insert += previousLine.charAt(i);
						i++;
					}
					int index = getLineStartOffset(line);
					if (!currentLine.startsWith(insert))
						this.document.insertString(index,insert,null);
				} catch (BadLocationException e) {
					e.printStackTrace();
				}
					
			}
			break;
		}
	}

	// protected members
	protected static String CENTER = "center";
	protected static String RIGHT = "right";
	protected static String BOTTOM = "bottom";

	protected static JCodeTextArea focusedComponent;
	protected static Timer caretTimer;

	protected TextAreaPainter painter;

	protected JPopupMenu popup;

	protected EventListenerList listenerList;
	protected MutableCaretEvent caretEvent;

	protected boolean caretBlinks;
	protected boolean caretVisible;
	protected boolean blink;

	protected boolean editable;

	protected int firstLine;
	protected int visibleLines;
	protected int electricScroll;

	protected int horizontalOffset;

	protected JScrollBar vertical;
	protected JScrollBar horizontal;
	protected boolean scrollBarsInitialized;

	protected InputHandler inputHandler;
	protected SyntaxDocument document;
	protected DocumentHandler documentHandler;

	protected Segment lineSegment;

	protected int selectionStart;
	protected int selectionStartLine;
	protected int selectionEnd;
	protected int selectionEndLine;
	protected boolean biasLeft;

	protected int bracketPosition;
	protected int bracketLine;

	protected int magicCaret;
	protected boolean overwrite;
	protected boolean rectSelect;

	protected void fireCaretEvent()
	{
		Object[] listeners = this.listenerList.getListenerList();
		for(int i = listeners.length - 2; i >= 0; i--)
		{
			if(listeners[i] == CaretListener.class)
			{
				((CaretListener)listeners[i+1]).caretUpdate(this.caretEvent);
			}
		}
	}

	protected void updateBracketHighlight(int newCaretPosition)
	{
		if(newCaretPosition == 0)
		{
			this.bracketPosition = this.bracketLine = -1;
			return;
		}

		try
		{
			int offset = TextUtilities.findMatchingBracket(
					this.document,newCaretPosition - 1);
			if(offset != -1)
			{
				this.bracketLine = this.getLineOfOffset(offset);
				this.bracketPosition = offset - this.getLineStartOffset(this.bracketLine);
				return;
			}
		}
		catch(BadLocationException bl)
		{
			bl.printStackTrace();
		}

		this.bracketLine = this.bracketPosition = -1;
	}

	protected void documentChanged(DocumentEvent evt)
	{
		DocumentEvent.ElementChange ch = evt.getChange(
				this.document.getDefaultRootElement());

		int count;
		if(ch == null)
			count = 0;
		else
			count = ch.getChildrenAdded().length -
			ch.getChildrenRemoved().length;

		int line = this.getLineOfOffset(evt.getOffset());
		if(count == 0)
		{
			this.painter.invalidateLine(line);
		}
		// do magic stuff
		else if(line < this.firstLine)
		{
			this.setFirstLine(this.firstLine + count);
		}
		// end of magic stuff
		else
		{
			this.painter.invalidateLineRange(line,this.firstLine + this.visibleLines);
			this.updateScrollBars();
		}
	}

	class ScrollLayout implements LayoutManager
	{
		@Override
		public void addLayoutComponent(String name, Component comp)
		{
			if(name.equals(CENTER))
				this.center = comp;
			else if(name.equals(RIGHT))
				this.right = comp;
			else if(name.equals(BOTTOM))
				this.bottom = comp;
			else if(name.equals(LEFT_OF_SCROLLBAR))
				this.leftOfScrollBar.addElement(comp);
		}

		@Override
		public void removeLayoutComponent(Component comp)
		{
			if(this.center == comp)
				this.center = null;
			if(this.right == comp)
				this.right = null;
			if(this.bottom == comp)
				this.bottom = null;
			else
				this.leftOfScrollBar.removeElement(comp);
		}

		@Override
		public Dimension preferredLayoutSize(Container parent)
		{
			Dimension dim = new Dimension();
			Insets insets = JCodeTextArea.this.getInsets();
			dim.width = insets.left + insets.right;
			dim.height = insets.top + insets.bottom;

			Dimension centerPref = this.center.getPreferredSize();
			dim.width += centerPref.width;
			dim.height += centerPref.height;
			Dimension rightPref = this.right.getPreferredSize();
			dim.width += rightPref.width;
			Dimension bottomPref = this.bottom.getPreferredSize();
			dim.height += bottomPref.height;

			return dim;
		}

		@Override
		public Dimension minimumLayoutSize(Container parent)
		{
			Dimension dim = new Dimension();
			Insets insets = JCodeTextArea.this.getInsets();
			dim.width = insets.left + insets.right;
			dim.height = insets.top + insets.bottom;

			Dimension centerPref = this.center.getMinimumSize();
			dim.width += centerPref.width;
			dim.height += centerPref.height;
			Dimension rightPref = this.right.getMinimumSize();
			dim.width += rightPref.width;
			Dimension bottomPref = this.bottom.getMinimumSize();
			dim.height += bottomPref.height;

			return dim;
		}

		@Override
		public void layoutContainer(Container parent)
		{
			Dimension size = parent.getSize();
			Insets insets = parent.getInsets();
			int itop = insets.top;
			int ileft = insets.left;
			int ibottom = insets.bottom;
			int iright = insets.right;

			int rightWidth = this.right.getPreferredSize().width;
			int bottomHeight = this.bottom.getPreferredSize().height;
			int centerWidth = size.width - rightWidth - ileft - iright;
			int centerHeight = size.height - bottomHeight - itop - ibottom;

			this.center.setBounds(
					ileft,
					itop,
					centerWidth,
					centerHeight);

			this.right.setBounds(
					ileft + centerWidth,
					itop,
					rightWidth,
					centerHeight);

			// Lay out all status components, in order
			Enumeration status = this.leftOfScrollBar.elements();
			while(status.hasMoreElements())
			{
				Component comp = (Component)status.nextElement();
				Dimension dim = comp.getPreferredSize();
				comp.setBounds(ileft,
						itop + centerHeight,
						dim.width,
						bottomHeight);
				ileft += dim.width;
			}

			this.bottom.setBounds(
					ileft,
					itop + centerHeight,
					size.width - rightWidth - ileft - iright,
					bottomHeight);
		}

		// private members
		private Component center;
		private Component right;
		private Component bottom;
		private Vector leftOfScrollBar = new Vector();
	}

	static class CaretBlinker implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent evt)
		{
			if(focusedComponent != null
					&& focusedComponent.hasFocus())
				focusedComponent.blinkCaret();
		}
	}

	class MutableCaretEvent extends CaretEvent
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		MutableCaretEvent()
		{
			super(JCodeTextArea.this);
		}

		@Override
		public int getDot()
		{
			return JCodeTextArea.this.getCaretPosition();
		}

		@Override
		public int getMark()
		{
			return JCodeTextArea.this.getMarkPosition();
		}
	}

	class AdjustHandler implements AdjustmentListener
	{
		@Override
		public void adjustmentValueChanged(final AdjustmentEvent evt)
		{
			if(!JCodeTextArea.this.scrollBarsInitialized)
				return;

			// If this is not done, mousePressed events accumulate
			// and the result is that scrolling doesn't stop after
			// the mouse is released
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run()
				{
					if(evt.getAdjustable() == JCodeTextArea.this.vertical)
						JCodeTextArea.this.setFirstLine(JCodeTextArea.this.vertical.getValue());
					else
						JCodeTextArea.this.setHorizontalOffset(-JCodeTextArea.this.horizontal.getValue());
				}
			});
		}
	}

	class ComponentHandler extends ComponentAdapter
	{
		@Override
		public void componentResized(ComponentEvent evt)
		{
			JCodeTextArea.this.recalculateVisibleLines();
			JCodeTextArea.this.scrollBarsInitialized = true;
		}
	}

	class DocumentHandler implements DocumentListener
	{
		@Override
		public void insertUpdate(DocumentEvent evt)
		{
			JCodeTextArea.this.documentChanged(evt);

			int offset = evt.getOffset();
			int length = evt.getLength();

			int newStart;
			int newEnd;

			if(JCodeTextArea.this.selectionStart > offset || (JCodeTextArea.this.selectionStart
					== JCodeTextArea.this.selectionEnd && JCodeTextArea.this.selectionStart == offset))
				newStart = JCodeTextArea.this.selectionStart + length;
			else
				newStart = JCodeTextArea.this.selectionStart;

			if(JCodeTextArea.this.selectionEnd >= offset)
				newEnd = JCodeTextArea.this.selectionEnd + length;
			else
				newEnd = JCodeTextArea.this.selectionEnd;

			JCodeTextArea.this.select(newStart,newEnd);
		}

		@Override
		public void removeUpdate(DocumentEvent evt)
		{
			JCodeTextArea.this.documentChanged(evt);

			int offset = evt.getOffset();
			int length = evt.getLength();

			int newStart;
			int newEnd;

			if(JCodeTextArea.this.selectionStart > offset)
			{
				if(JCodeTextArea.this.selectionStart > offset + length)
					newStart = JCodeTextArea.this.selectionStart - length;
				else
					newStart = offset;
			}
			else
				newStart = JCodeTextArea.this.selectionStart;

			if(JCodeTextArea.this.selectionEnd > offset)
			{
				if(JCodeTextArea.this.selectionEnd > offset + length)
					newEnd = JCodeTextArea.this.selectionEnd - length;
				else
					newEnd = offset;
			}
			else
				newEnd = JCodeTextArea.this.selectionEnd;

			JCodeTextArea.this.select(newStart,newEnd);
		}

		@Override
		public void changedUpdate(DocumentEvent evt)
		{
		}
	}

	class DragHandler implements MouseMotionListener
	{
		@Override
		public void mouseDragged(MouseEvent evt)
		{
			if(JCodeTextArea.this.popup != null && JCodeTextArea.this.popup.isVisible())
				return;

			JCodeTextArea.this.setSelectionRectangular((evt.getModifiers()
					& InputEvent.CTRL_MASK) != 0);
			JCodeTextArea.this.select(JCodeTextArea.this.getMarkPosition(),JCodeTextArea.this.xyToOffset(evt.getX(),evt.getY()));
		}

		@Override
		public void mouseMoved(MouseEvent evt) {}
	}

	class FocusHandler implements FocusListener
	{
		@Override
		public void focusGained(FocusEvent evt)
		{
			JCodeTextArea.this.setCaretVisible(true);
			focusedComponent = JCodeTextArea.this;
		}

		@Override
		public void focusLost(FocusEvent evt)
		{
			JCodeTextArea.this.setCaretVisible(false);
			focusedComponent = null;
		}
	}

	class MouseHandler extends MouseAdapter
	{
		@Override
		public void mousePressed(MouseEvent evt)
		{
			JCodeTextArea.this.requestFocus();

			// Focus events not fired sometimes?
			JCodeTextArea.this.setCaretVisible(true);
			focusedComponent = JCodeTextArea.this;

			if((evt.getModifiers() & InputEvent.BUTTON3_MASK) != 0
					&& JCodeTextArea.this.popup != null)
			{
				JCodeTextArea.this.popup.show(JCodeTextArea.this.painter,evt.getX(),evt.getY());
				return;
			}

			int line = JCodeTextArea.this.yToLine(evt.getY());
			int offset = JCodeTextArea.this.xToOffset(line,evt.getX());
			int dot = JCodeTextArea.this.getLineStartOffset(line) + offset;

			switch(evt.getClickCount())
			{
			case 1:
				this.doSingleClick(evt,line,offset,dot);
				break;
			case 2:
				// It uses the bracket matching stuff, so
				// it can throw a BLE
				try
				{
					this.doDoubleClick(evt,line,offset,dot);
				}
				catch(BadLocationException bl)
				{
					bl.printStackTrace();
				}
				break;
			case 3:
				this.doTripleClick(evt,line,offset,dot);
				break;
			}
		}

		private void doSingleClick(MouseEvent evt, int line,
				int offset, int dot)
		{
			if((evt.getModifiers() & InputEvent.SHIFT_MASK) != 0)
			{
				JCodeTextArea.this.rectSelect = (evt.getModifiers() & InputEvent.CTRL_MASK) != 0;
				JCodeTextArea.this.select(JCodeTextArea.this.getMarkPosition(),dot);
			}
			else
				JCodeTextArea.this.setCaretPosition(dot);
		}

		private void doDoubleClick(MouseEvent evt, int line,
				int offset, int dot) throws BadLocationException
		{
			// Ignore empty lines
			if(JCodeTextArea.this.getLineLength(line) == 0)
				return;

			try
			{
				int bracket = TextUtilities.findMatchingBracket(
						JCodeTextArea.this.document,Math.max(0,dot - 1));
				if(bracket != -1)
				{
					int mark = JCodeTextArea.this.getMarkPosition();
					// Hack
					if(bracket > mark)
					{
						bracket++;
						mark--;
					}
					JCodeTextArea.this.select(mark,bracket);
					return;
				}
			}
			catch(BadLocationException bl)
			{
				bl.printStackTrace();
			}

			// Ok, it's not a bracket... select the word
			String lineText = JCodeTextArea.this.getLineText(line);
			char ch = lineText.charAt(Math.max(0,offset - 1));

			String noWordSep = (String)JCodeTextArea.this.document.getProperty("noWordSep");
			if(noWordSep == null)
				noWordSep = "";

			// If the user clicked on a non-letter char,
			// we select the surrounding non-letters
			boolean selectNoLetter = (!Character
					.isLetterOrDigit(ch)
					&& noWordSep.indexOf(ch) == -1);

			int wordStart = 0;

			for(int i = offset - 1; i >= 0; i--)
			{
				ch = lineText.charAt(i);
				if(selectNoLetter ^ (!Character
						.isLetterOrDigit(ch) &&
						noWordSep.indexOf(ch) == -1))
				{
					wordStart = i + 1;
					break;
				}
			}

			int wordEnd = lineText.length();
			for(int i = offset; i < lineText.length(); i++)
			{
				ch = lineText.charAt(i);
				if(selectNoLetter ^ (!Character
						.isLetterOrDigit(ch) &&
						noWordSep.indexOf(ch) == -1))
				{
					wordEnd = i;
					break;
				}
			}

			int lineStart = JCodeTextArea.this.getLineStartOffset(line);
			JCodeTextArea.this.select(lineStart + wordStart,lineStart + wordEnd);

			/*
			String lineText = getLineText(line);
			String noWordSep = (String)document.getProperty("noWordSep");
			int wordStart = TextUtilities.findWordStart(lineText,offset,noWordSep);
			int wordEnd = TextUtilities.findWordEnd(lineText,offset,noWordSep);

			int lineStart = getLineStartOffset(line);
			select(lineStart + wordStart,lineStart + wordEnd);
			 */
		}

		private void doTripleClick(MouseEvent evt, int line,
				int offset, int dot)
		{
			JCodeTextArea.this.select(JCodeTextArea.this.getLineStartOffset(line),JCodeTextArea.this.getLineEndOffset(line)-1);
		}
	}

	class CaretUndo extends AbstractUndoableEdit
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int start;
		private int end;

		CaretUndo(int start, int end)
		{
			this.start = start;
			this.end = end;
		}

		@Override
		public boolean isSignificant()
		{
			return false;
		}

		@Override
		public String getPresentationName()
		{
			return "caret move";
		}

		@Override
		public void undo() throws CannotUndoException
		{
			super.undo();

			JCodeTextArea.this.select(this.start,this.end);
		}

		@Override
		public void redo() throws CannotRedoException
		{
			super.redo();

			JCodeTextArea.this.select(this.start,this.end);
		}

		@Override
		public boolean addEdit(UndoableEdit edit)
		{
			if(edit instanceof CaretUndo)
			{
				CaretUndo cedit = (CaretUndo)edit;
				this.start = cedit.start;
				this.end = cedit.end;
				cedit.die();

				return true;
			}
			else
				return false;
		}
	}

	static
	{
		caretTimer = new Timer(500,new CaretBlinker());
		caretTimer.setInitialDelay(500);
		caretTimer.start();
	}

	/* ERROR MANAGEMENT */

	class ErrorLocation{
		int Line, Pos, Len;
		String Message;
		Kind error_kind;
		boolean over =false;
		Rectangle bound = new Rectangle();
		public ErrorLocation(int line, int pos, int length,Kind kind, String message){
			this.Line = line;
			this.Pos = pos ;
			this.Len = length;
			this.Message = message;
			this.error_kind = kind;
		}
	}

	Vector<ErrorLocation> errors = new Vector<ErrorLocation>();
	Vector<ErrorLocation> errors_on_line = new Vector<ErrorLocation>();

	public Vector<ErrorLocation> getError(int line) {
		this.errors_on_line.clear();
		for(ErrorLocation error : this.errors)
			if (error.Line==line)
				this.errors_on_line.add(error);
		return this.errors_on_line;
	}

	public void clearErrors()
	{
		this.errors.clear();
	}

	public void addErrorOnLine(long lineNumber, long columnNumber, long l, Kind kind, String message) {
		if (l<=0)
			this.errors.add(new ErrorLocation((int) lineNumber, 0, 100, kind, message));
		else
			this.errors.add(new ErrorLocation((int) lineNumber, (int) columnNumber, (int) l, kind,  message));
	}


	@Override
	public void mouseMoved(MouseEvent e) {

		for(ErrorLocation error : this.errors){
			error.over = false;
			if (error.bound.contains(e.getPoint())){
				error.over = true;
				this.popupInfo.show(e.getXOnScreen()-e.getX() + (int) error.bound.getX()+20, e.getYOnScreen()-e.getY() +(int) error.bound.getY()+25,error.Message);
				return;
			}
		}
		this.popupInfo.setVisible(false);
		this.repaint();
	}




	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public Point getCaretLocation() {
		Point p = painter.getCarretPosition();
		p.x += this.getLocation().x;
		p.y += this.getLocation().y;
		return p;
	}

	Vector<String> Shader_Input_Uniform = new Vector<>();
	public Vector<String> getShaderInUni() {
		return Shader_Input_Uniform;
	}
	public void setShaderInUni(Vector<String> list) {
		Shader_Input_Uniform.clear();
		Shader_Input_Uniform.addAll(list);
	}

	public boolean isUnsaved() {
		return unsaved;
	}

	public void save() {
		if (associatedFile == null) {
			MainEditor.saveAsFile(this);
		}
		else if (writeFile()){
			unsaved = false;
			if (saveLis != null) saveLis.setSaved(true);
		}
	}
	public void saveAs(File f) {

		associatedFile = f;
		if (writeFile()){
			if (saveLis != null) saveLis.setSaved(true);
			unsaved = false;
		}
	}

	private boolean writeFile() {

		try {
			String savePath = associatedFile.getAbsolutePath();
			if (associatedFile.exists())
				associatedFile.renameTo(new File(savePath+"~"));
			
			PrintStream ps = new PrintStream(savePath);
			ps.print(getText());
			ps.flush();
			ps.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

}
