
package fr.egl.widgets.code_editor;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.JComponent;
import javax.swing.ToolTipManager;
import javax.swing.text.PlainDocument;
import javax.swing.text.Segment;
import javax.swing.text.TabExpander;
import javax.swing.text.Utilities;
import javax.tools.Diagnostic.Kind;

import fr.egl.widgets.code_editor.syntax.SyntaxToken;
import fr.egl.widgets.code_editor.syntax.SyntaxTokenMarker;

/**
 * The text area repaint manager. It performs double buffering and paints
 * lines of text.
 */
public class TextAreaPainter extends JComponent implements TabExpander
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Creates a new repaint manager. This should be not be called
	 * directly.
	 */
	public TextAreaPainter(JCodeTextArea textArea, TextAreaDefaults defaults)
	{
		this.textArea = textArea;

		this.setAutoscrolls(true);
		this.setDoubleBuffered(true);
		this.setOpaque(true);

		ToolTipManager.sharedInstance().registerComponent(this);

		this.currentLine = new Segment();
		this.currentLineIndex = -1;

		this.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));

		this.setFont(new Font("Monospaced",Font.PLAIN,14));
		this.setForeground(Color.black);
		this.setBackground(Color.white);

		this.blockCaret = defaults.blockCaret;
		this.styles = defaults.styles;
		this.cols = defaults.cols;
		this.rows = defaults.rows;
		this.caretColor = defaults.caretColor;
		this.selectionColor = defaults.selectionColor;
		this.lineHighlightColor = defaults.lineHighlightColor;
		this.lineHighlight = defaults.lineHighlight;
		this.bracketHighlightColor = defaults.bracketHighlightColor;
		this.bracketHighlight = defaults.bracketHighlight;
		this.paintInvalid = defaults.paintInvalid;
		this.eolMarkerColor = defaults.eolMarkerColor;
		this.eolMarkers = defaults.eolMarkers;
	}

	private Point last_caret_pos = new Point(0, 0);
	public Point getCarretPosition(){
		return last_caret_pos;
	}

	/**
	 * Returns if this component can be traversed by pressing the
	 * Tab key. This returns false.
	 */
	@Override
	public final boolean isManagingFocus()
	{
		return false;
	}

	/**
	 * Returns the syntax styles used to paint colorized text. Entry <i>n</i>
	 * will be used to paint tokens with id = <i>n</i>.
	 * @see org.SyntaxToken.jedit.Token
	 */
	public final SyntaxStyle[] getStyles()
	{
		return this.styles;
	}

	/**
	 * Sets the syntax styles used to paint colorized text. Entry <i>n</i>
	 * will be used to paint tokens with id = <i>n</i>.
	 * @param styles The syntax styles
	 * @see org.SyntaxToken.jedit.Token
	 */
	public final void setStyles(SyntaxStyle[] styles)
	{
		this.styles = styles;
		this.repaint();
	}

	/**
	 * Returns the caret color.
	 */
	public final Color getCaretColor()
	{
		return this.caretColor;
	}

	/**
	 * Sets the caret color.
	 * @param caretColor The caret color
	 */
	public final void setCaretColor(Color caretColor)
	{
		this.caretColor = caretColor;
		this.invalidateSelectedLines();
	}

	/**
	 * Returns the selection color.
	 */
	public final Color getSelectionColor()
	{
		return this.selectionColor;
	}

	/**
	 * Sets the selection color.
	 * @param selectionColor The selection color
	 */
	public final void setSelectionColor(Color selectionColor)
	{
		this.selectionColor = selectionColor;
		this.invalidateSelectedLines();
	}

	/**
	 * Returns the line highlight color.
	 */
	public final Color getLineHighlightColor()
	{
		return this.lineHighlightColor;
	}

	/**
	 * Sets the line highlight color.
	 * @param lineHighlightColor The line highlight color
	 */
	public final void setLineHighlightColor(Color lineHighlightColor)
	{
		this.lineHighlightColor = lineHighlightColor;
		this.invalidateSelectedLines();
	}

	/**
	 * Returns true if line highlight is enabled, false otherwise.
	 */
	public final boolean isLineHighlightEnabled()
	{
		return this.lineHighlight;
	}

	/**
	 * Enables or disables current line highlighting.
	 * @param lineHighlight True if current line highlight should be enabled,
	 * false otherwise
	 */
	public final void setLineHighlightEnabled(boolean lineHighlight)
	{
		this.lineHighlight = lineHighlight;
		this.invalidateSelectedLines();
	}

	/**
	 * Returns the bracket highlight color.
	 */
	public final Color getBracketHighlightColor()
	{
		return this.bracketHighlightColor;
	}

	/**
	 * Sets the bracket highlight color.
	 * @param bracketHighlightColor The bracket highlight color
	 */
	public final void setBracketHighlightColor(Color bracketHighlightColor)
	{
		this.bracketHighlightColor = bracketHighlightColor;
		this.invalidateLine(this.textArea.getBracketLine());
	}

	/**
	 * Returns true if bracket highlighting is enabled, false otherwise.
	 * When bracket highlighting is enabled, the bracket matching the
	 * one before the caret (if any) is highlighted.
	 */
	public final boolean isBracketHighlightEnabled()
	{
		return this.bracketHighlight;
	}

	/**
	 * Enables or disables bracket highlighting.
	 * When bracket highlighting is enabled, the bracket matching the
	 * one before the caret (if any) is highlighted.
	 * @param bracketHighlight True if bracket highlighting should be
	 * enabled, false otherwise
	 */
	public final void setBracketHighlightEnabled(boolean bracketHighlight)
	{
		this.bracketHighlight = bracketHighlight;
		this.invalidateLine(this.textArea.getBracketLine());
	}

	/**
	 * Returns true if the caret should be drawn as a block, false otherwise.
	 */
	public final boolean isBlockCaretEnabled()
	{
		return this.blockCaret;
	}

	/**
	 * Sets if the caret should be drawn as a block, false otherwise.
	 * @param blockCaret True if the caret should be drawn as a block,
	 * false otherwise.
	 */
	public final void setBlockCaretEnabled(boolean blockCaret)
	{
		this.blockCaret = blockCaret;
		this.invalidateSelectedLines();
	}

	/**
	 * Returns the EOL marker color.
	 */
	public final Color getEOLMarkerColor()
	{
		return this.eolMarkerColor;
	}

	/**
	 * Sets the EOL marker color.
	 * @param eolMarkerColor The EOL marker color
	 */
	public final void setEOLMarkerColor(Color eolMarkerColor)
	{
		this.eolMarkerColor = eolMarkerColor;
		this.repaint();
	}

	/**
	 * Returns true if EOL markers are drawn, false otherwise.
	 */
	public final boolean getEOLMarkersPainted()
	{
		return this.eolMarkers;
	}

	/**
	 * Sets if EOL markers are to be drawn.
	 * @param eolMarkers True if EOL markers should be drawn, false otherwise
	 */
	public final void setEOLMarkersPainted(boolean eolMarkers)
	{
		this.eolMarkers = eolMarkers;
		this.repaint();
	}

	/**
	 * Returns true if invalid lines are painted as red tildes (~),
	 * false otherwise.
	 */
	public boolean getInvalidLinesPainted()
	{
		return this.paintInvalid;
	}

	/**
	 * Sets if invalid lines are to be painted as red tildes.
	 * @param paintInvalid True if invalid lines should be drawn, false otherwise
	 */
	public void setInvalidLinesPainted(boolean paintInvalid)
	{
		this.paintInvalid = paintInvalid;
	}

	/**
	 * Adds a custom highlight painter.
	 * @param highlight The highlight
	 */
	public void addCustomHighlight(Highlight highlight)
	{
		highlight.init(this.textArea,this.highlights);
		this.highlights = highlight;
	}

	/**
	 * Highlight interface.
	 */
	public interface Highlight
	{
		/**
		 * Called after the highlight painter has been added.
		 * @param textArea The text area
		 * @param next The painter this one should delegate to
		 */
		void init(JCodeTextArea textArea, Highlight next);

		/**
		 * This should paint the highlight and delgate to the
		 * next highlight painter.
		 * @param gfx The graphics context
		 * @param line The line number
		 * @param y The y co-ordinate of the line
		 */
		void paintHighlight(Graphics gfx, int line, int y);

		/**
		 * Returns the tool tip to display at the specified
		 * location. If this highlighter doesn't know what to
		 * display, it should delegate to the next highlight
		 * painter.
		 * @param evt The mouse event
		 */
		String getToolTipText(MouseEvent evt);
	}

	/**
	 * Returns the tool tip to display at the specified location.
	 * @param evt The mouse event
	 */
	@Override
	public String getToolTipText(MouseEvent evt)
	{
		if(this.highlights != null)
			return this.highlights.getToolTipText(evt);
		else
			return null;
	}

	/**
	 * Returns the font metrics used by this component.
	 */
	public FontMetrics getFontMetrics()
	{
		return this.fm;
	}

	/**
	 * Sets the font for this component. This is overridden to update the
	 * cached font metrics and to recalculate which lines are visible.
	 * @param font The font
	 */
	@Override
	public void setFont(Font font)
	{
		super.setFont(font);
		this.fm = Toolkit.getDefaultToolkit().getFontMetrics(font);
		this.textArea.recalculateVisibleLines();
	}

	/**
	 * Repaints the text.
	 * @param g The graphics context
	 */
	@Override
	public void paint(Graphics gfx)
	{

		((Graphics2D) gfx).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		this.tabSize = this.fm.charWidth(' ') * ((Integer)this.textArea
				.getDocument().getProperty(
						PlainDocument.tabSizeAttribute)).intValue();

		Rectangle clipRect = gfx.getClipBounds();

		gfx.setColor(this.getBackground());
		gfx.fillRect(clipRect.x,clipRect.y,clipRect.width,clipRect.height);

		// We don't use yToLine() here because that method doesn't
		// return lines past the end of the document
		int height = this.fm.getHeight();
		int firstLine = this.textArea.getFirstLine();
		int firstInvalid = firstLine + clipRect.y / height;
		// Because the clipRect's height is usually an even multiple
		// of the font height, we subtract 1 from it, otherwise one
		// too many lines will always be painted.
		int lastInvalid = firstLine + (clipRect.y + clipRect.height - 1) / height;

		try
		{
			SyntaxTokenMarker tokenMarker = this.textArea.getDocument()
					.getTokenMarker();
			int x = this.textArea.getHorizontalOffset();

			//	System.out.println(firstInvalid +"  to  "+lastInvalid);
			for(int line = firstInvalid; line <= lastInvalid; line++)
			{
				this.paintLine(gfx,tokenMarker,line,x);
				Vector<JCodeTextArea.ErrorLocation> errors = this.textArea.getError(line);
				for (JCodeTextArea.ErrorLocation er : errors)
				{
					gfx.setColor(Color.red);
					if (er.error_kind == Kind.WARNING) gfx.setColor(Color.orange);
					int y = this.textArea.lineToY(line);
					for(int dx = er.Pos*8-8;dx< Math.min(this.getWidth(),(er.Pos+er.Len)*8-8);dx +=8){
						gfx.drawLine(dx  , y+height+3, dx+4, y+height+1);
						gfx.drawLine(dx+8, y+height+3, dx+4, y+height+1);
					}
					er.bound.setBounds(er.Pos*8-8,y+height-15,(er.Len)*8,18);/*
						if (er.over){
							gfx.setClip(null);

							Rectangle2D d = gfx.getFont().getStringBounds(er.Message, ((Graphics2D) gfx).getFontRenderContext());
							int ex = er.Pos*8-8;
							int ey = y+height;
							int w = (int)d.getWidth();
							int h = (int)d.getHeight();

							String[] lines = er.Message.split("\n");

							gfx.setColor(Color.white);
							gfx.fillRect(ex,ey,w+10,h*lines.length+10);
							gfx.setColor(Color.red);
							gfx.drawRect(ex,ey,w+10,h*lines.length+10);
							int py = ey + h;
							for(String error_line: lines){
								gfx.setColor(Color.black);
								gfx.drawString(error_line, ex+5, py);
								py += h;
							}

							gfx.setClip(clipRect);
						}*/
				}
			}

			if(tokenMarker != null && tokenMarker.isNextLineRequested())
			{
				int h = clipRect.y + clipRect.height;
				this.repaint(0,h,this.getWidth(),this.getHeight() - h);
			}
		}
		catch(Exception e)
		{
			System.err.println("Error repainting line"
					+ " range {" + firstInvalid + ","
					+ lastInvalid + "}:");
			e.printStackTrace();
		}
	}

	/**
	 * Marks a line as needing a repaint.
	 * @param line The line to invalidate
	 */
	public final void invalidateLine(int line)
	{
		this.repaint(0,this.textArea.lineToY(line) + this.fm.getMaxDescent() + this.fm.getLeading(),
				this.getWidth(),this.fm.getHeight());
	}

	/**
	 * Marks a range of lines as needing a repaint.
	 * @param firstLine The first line to invalidate
	 * @param lastLine The last line to invalidate
	 */
	public final void invalidateLineRange(int firstLine, int lastLine)
	{
		this.repaint(0,this.textArea.lineToY(firstLine) + this.fm.getMaxDescent() + this.fm.getLeading(),
				this.getWidth(),(lastLine - firstLine + 1) * this.fm.getHeight());
	}

	/**
	 * Repaints the lines containing the selection.
	 */
	public final void invalidateSelectedLines()
	{
		this.invalidateLineRange(this.textArea.getSelectionStartLine(),
				this.textArea.getSelectionEndLine());
	}

	/**
	 * Implementation of TabExpander interface. Returns next tab stop after
	 * a specified point.
	 * @param x The x co-ordinate
	 * @param tabOffset Ignored
	 * @return The next tab stop after <i>x</i>
	 */
	@Override
	public float nextTabStop(float x, int tabOffset)
	{
		int offset = this.textArea.getHorizontalOffset();
		int ntabs = ((int)x - offset) / this.tabSize;
		return (ntabs + 1) * this.tabSize + offset;
	}

	/**
	 * Returns the painter's preferred size.
	 */
	@Override
	public Dimension getPreferredSize()
	{
		Dimension dim = new Dimension();
		dim.width = this.fm.charWidth('w') * this.cols;
		dim.height = this.fm.getHeight() * this.rows;
		return dim;
	}


	/**
	 * Returns the painter's minimum size.
	 */
	@Override
	public Dimension getMinimumSize()
	{
		return this.getPreferredSize();
	}

	// package-private members
	int currentLineIndex;
	SyntaxToken currentLineTokens;
	Segment currentLine;

	// protected members
	protected JCodeTextArea textArea;

	protected SyntaxStyle[] styles;
	protected Color caretColor;
	protected Color selectionColor;
	protected Color lineHighlightColor;
	protected Color bracketHighlightColor;
	protected Color eolMarkerColor;

	protected boolean blockCaret;
	protected boolean lineHighlight;
	protected boolean bracketHighlight;
	protected boolean paintInvalid;
	protected boolean eolMarkers;
	protected int cols;
	protected int rows;

	protected int tabSize;
	protected FontMetrics fm;

	protected Highlight highlights;

	protected void paintLine(Graphics gfx, SyntaxTokenMarker tokenMarker,
			int line, int x)
	{
		Font defaultFont = this.getFont();
		Color defaultColor = this.getForeground();

		this.currentLineIndex = line;
		int y = this.textArea.lineToY(line);

		if(line < 0 || line >= this.textArea.getLineCount())
		{
			if(this.paintInvalid)
			{
				this.paintHighlight(gfx,line,y);
				this.styles[SyntaxToken.INVALID].setGraphicsFlags(gfx,defaultFont);
				gfx.drawString("~",0,y + this.fm.getHeight());
			}
		}
		else if(tokenMarker == null)
		{
			this.paintPlainLine(gfx,line,defaultFont,defaultColor,x,y);
		}
		else
		{
			this.paintSyntaxLine(gfx,tokenMarker,line,defaultFont,
					defaultColor,x,y);
		}
	}

	protected void paintPlainLine(Graphics gfx, int line, Font defaultFont,
			Color defaultColor, int x, int y)
	{
		this.paintHighlight(gfx,line,y);
		this.textArea.getLineText(line,this.currentLine);

		gfx.setFont(defaultFont);
		gfx.setColor(defaultColor);

		y += this.fm.getHeight();
		x = Utilities.drawTabbedText(this.currentLine,x,y,gfx,this,0);

		if(this.eolMarkers)
		{
			gfx.setColor(this.eolMarkerColor);
			gfx.drawString(".",x,y);
		}
	}
	
	static final Color lineCounterColor = Color.gray;

	protected void paintSyntaxLine(Graphics gfx, SyntaxTokenMarker tokenMarker,
			int line, Font defaultFont, Color defaultColor, int x, int y)
	{
		this.textArea.getLineText(this.currentLineIndex,this.currentLine);
		this.currentLineTokens = tokenMarker.markTokens(this.currentLine,
				this.currentLineIndex);

		this.paintHighlight(gfx,line,y);

		gfx.setFont(defaultFont);
		gfx.setColor(defaultColor);
		y += this.fm.getHeight();
		x = SyntaxUtilities.paintSyntaxLine(this.currentLine,
				this.currentLineTokens,this.styles,this,gfx,x,y);

		gfx.setFont(defaultFont);		
		gfx.setColor(lineCounterColor);		
		gfx.drawString(""+(line+1),getWidth()-gfx.getFontMetrics().stringWidth(""+(line+1))-5,y);

		if(this.eolMarkers)
		{
			gfx.setColor(this.eolMarkerColor);
			gfx.drawString(".",x,y);
		}
	}

	protected void paintHighlight(Graphics gfx, int line, int y)
	{
		if(line >= this.textArea.getSelectionStartLine()
				&& line <= this.textArea.getSelectionEndLine())
			this.paintLineHighlight(gfx,line,y);

		if(this.highlights != null)
			this.highlights.paintHighlight(gfx,line,y);

		if(this.bracketHighlight && line == this.textArea.getBracketLine())
			this.paintBracketHighlight(gfx,line,y);

		if(line == this.textArea.getCaretLine())
			this.paintCaret(gfx,line,y);
	}

	protected void paintLineHighlight(Graphics gfx, int line, int y)
	{
		int height = this.fm.getHeight();
		y += this.fm.getLeading() + this.fm.getMaxDescent();

		int selectionStart = this.textArea.getSelectionStart();
		int selectionEnd = this.textArea.getSelectionEnd();

		if(selectionStart == selectionEnd)
		{
			if(this.lineHighlight)
			{
				gfx.setColor(this.lineHighlightColor);
				gfx.fillRect(0,y,this.getWidth(),height);
			}
		}
		else
		{
			gfx.setColor(this.selectionColor);

			int selectionStartLine = this.textArea.getSelectionStartLine();
			int selectionEndLine = this.textArea.getSelectionEndLine();
			int lineStart = this.textArea.getLineStartOffset(line);

			int x1, x2;
			if(this.textArea.isSelectionRectangular())
			{
				int lineLen = this.textArea.getLineLength(line);
				x1 = this.textArea._offsetToX(line,Math.min(lineLen,
						selectionStart - this.textArea.getLineStartOffset(
								selectionStartLine)));
				x2 = this.textArea._offsetToX(line,Math.min(lineLen,
						selectionEnd - this.textArea.getLineStartOffset(
								selectionEndLine)));
				if(x1 == x2)
					x2++;
			}
			else if(selectionStartLine == selectionEndLine)
			{
				x1 = this.textArea._offsetToX(line,
						selectionStart - lineStart);
				x2 = this.textArea._offsetToX(line,
						selectionEnd - lineStart);
			}
			else if(line == selectionStartLine)
			{
				x1 = this.textArea._offsetToX(line,
						selectionStart - lineStart);
				x2 = this.getWidth();
			}
			else if(line == selectionEndLine)
			{
				x1 = 0;
				x2 = this.textArea._offsetToX(line,
						selectionEnd - lineStart);
			}
			else
			{
				x1 = 0;
				x2 = this.getWidth();
			}

			// "inlined" min/max()
			gfx.fillRect(x1 > x2 ? x2 : x1,y,x1 > x2 ?
					(x1 - x2) : (x2 - x1),height);
		}

	}

	protected void paintBracketHighlight(Graphics gfx, int line, int y)
	{
		int position = this.textArea.getBracketPosition();
		if(position == -1)
			return;
		y += this.fm.getLeading() + this.fm.getMaxDescent();
		int x = this.textArea._offsetToX(line,position);
		gfx.setColor(this.bracketHighlightColor);
		// Hack!!! Since there is no fast way to get the character
		// from the bracket matching routine, we use ( since all
		// brackets probably have the same width anyway
		gfx.drawRect(x,y,this.fm.charWidth('(') - 1,
				this.fm.getHeight() - 1);
	}

	protected void paintCaret(Graphics gfx, int line, int y)
	{

		int offset = this.textArea.getCaretPosition()
				- this.textArea.getLineStartOffset(line);
		int caretX = this.textArea._offsetToX(line,offset);
		int caretWidth = ((this.blockCaret ||
				this.textArea.isOverwriteEnabled()) ?
						this.fm.charWidth('w') : 1);
		y += this.fm.getLeading() + this.fm.getMaxDescent();
		int height = this.fm.getHeight();

		last_caret_pos.x = caretX +2;
		last_caret_pos.y = y + 2;

		if(this.textArea.isCaretVisible())
		{
			gfx.setColor(this.caretColor);
			if(this.textArea.isOverwriteEnabled())
			{
				gfx.fillRect(caretX,y + height - 1,
						caretWidth,1);
			}
			else
			{
				gfx.drawRect(caretX,y,caretWidth, height - 1);
			}
		}


	}


}
