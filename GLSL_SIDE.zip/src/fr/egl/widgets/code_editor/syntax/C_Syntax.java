/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */


package fr.egl.widgets.code_editor.syntax;

import javax.swing.text.Segment;

import fr.egl.widgets.code_editor.KeywordMap;

public class C_Syntax extends SyntaxTokenMarker
{
	public C_Syntax()
	{
		this(true,getKeywords());
	}

	public C_Syntax(boolean cpp, KeywordMap keywords)
	{
		this.cpp = cpp;
		this.keywords = keywords;
	}

	@Override
	public byte markTokensImpl(byte token, Segment line, int lineIndex)
	{
		char[] array = line.array;
		int offset = line.offset;
		this.lastOffset = offset;
		this.lastKeyword = offset;
		int length = line.count + offset;
		boolean backslash = false;

		loop:		for(int i = offset; i < length; i++)
		{
			int i1 = (i+1);

			char c = array[i];
			if(c == '\\')
			{
				backslash = !backslash;
				continue;
			}

			switch(token)
			{
			case SyntaxToken.NULL:
				switch(c)
				{
				case '#':
					if(backslash)
						backslash = false;
					else if(this.cpp)
					{
						if(this.doKeyword(line,i,c))
							break;
						this.addToken(i - this.lastOffset,token);
						this.addToken(length - i,SyntaxToken.KEYWORD2);
						this.lastOffset = this.lastKeyword = length;
						break loop;
					}
					break;
				case '"':
					this.doKeyword(line,i,c);
					if(backslash)
						backslash = false;
					else
					{
						this.addToken(i - this.lastOffset,token);
						token = SyntaxToken.LITERAL1;
						this.lastOffset = this.lastKeyword = i;
					}
					break;
				case '\'':
					this.doKeyword(line,i,c);
					if(backslash)
						backslash = false;
					else
					{
						this.addToken(i - this.lastOffset,token);
						token = SyntaxToken.LITERAL2;
						this.lastOffset = this.lastKeyword = i;
					}
					break;
				case ':':
					if(this.lastKeyword == offset)
					{
						if(this.doKeyword(line,i,c))
							break;
						backslash = false;
						this.addToken(i1 - this.lastOffset,SyntaxToken.LABEL);
						this.lastOffset = this.lastKeyword = i1;
					}
					else if(this.doKeyword(line,i,c))
						break;
					break;
				case '/':
					backslash = false;
					this.doKeyword(line,i,c);
					if(length - i > 1)
					{
						switch(array[i1])
						{
						case '*':
							this.addToken(i - this.lastOffset,token);
							this.lastOffset = this.lastKeyword = i;
							if(length - i > 2 && array[i+2] == '*')
								token = SyntaxToken.COMMENT2;
							else
								token = SyntaxToken.COMMENT1;
							break;
						case '/':
							this.addToken(i - this.lastOffset,token);
							this.addToken(length - i,SyntaxToken.COMMENT1);
							this.lastOffset = this.lastKeyword = length;
							break loop;
						}
					}
					break;
				default:
					backslash = false;
					if(!Character.isLetterOrDigit(c)
							&& c != '_')
						this.doKeyword(line,i,c);
					break;
				}
				break;
			case SyntaxToken.COMMENT1:
			case SyntaxToken.COMMENT2:
				backslash = false;
				if(c == '*' && length - i > 1)
				{
					if(array[i1] == '/')
					{
						i++;
						this.addToken((i+1) - this.lastOffset,token);
						token = SyntaxToken.NULL;
						this.lastOffset = this.lastKeyword = i+1;
					}
				}
				break;
			case SyntaxToken.LITERAL1:
				if(backslash)
					backslash = false;
				else if(c == '"')
				{
					this.addToken(i1 - this.lastOffset,token);
					token = SyntaxToken.NULL;
					this.lastOffset = this.lastKeyword = i1;
				}
				break;
			case SyntaxToken.LITERAL2:
				if(backslash)
					backslash = false;
				else if(c == '\'')
				{
					this.addToken(i1 - this.lastOffset,SyntaxToken.LITERAL1);
					token = SyntaxToken.NULL;
					this.lastOffset = this.lastKeyword = i1;
				}
				break;
			default:
				throw new InternalError("Invalid state: "
						+ token);
			}
		}

		if(token == SyntaxToken.NULL)
			this.doKeyword(line,length,'\0');

		switch(token)
		{
		case SyntaxToken.LITERAL1:
		case SyntaxToken.LITERAL2:
			this.addToken(length - this.lastOffset,SyntaxToken.INVALID);
			token = SyntaxToken.NULL;
			break;
		case SyntaxToken.KEYWORD2:
			this.addToken(length - this.lastOffset,token);
			if(!backslash)
				token = SyntaxToken.NULL;
		default:
			this.addToken(length - this.lastOffset,token);
			break;
		}

		return token;
	}

	public static KeywordMap getKeywords()
	{
		if(cKeywords == null)
		{
			cKeywords = new KeywordMap(false);
			cKeywords.add("char",SyntaxToken.KEYWORD3);
			cKeywords.add("double",SyntaxToken.KEYWORD3);
			cKeywords.add("enum",SyntaxToken.KEYWORD3);
			cKeywords.add("float",SyntaxToken.KEYWORD3);
			cKeywords.add("int",SyntaxToken.KEYWORD3);
			cKeywords.add("long",SyntaxToken.KEYWORD3);
			cKeywords.add("short",SyntaxToken.KEYWORD3);
			cKeywords.add("signed",SyntaxToken.KEYWORD3);
			cKeywords.add("struct",SyntaxToken.KEYWORD3);
			cKeywords.add("typedef",SyntaxToken.KEYWORD3);
			cKeywords.add("union",SyntaxToken.KEYWORD3);
			cKeywords.add("unsigned",SyntaxToken.KEYWORD3);
			cKeywords.add("void",SyntaxToken.KEYWORD3);
			cKeywords.add("auto",SyntaxToken.KEYWORD1);
			cKeywords.add("const",SyntaxToken.KEYWORD1);
			cKeywords.add("extern",SyntaxToken.KEYWORD1);
			cKeywords.add("register",SyntaxToken.KEYWORD1);
			cKeywords.add("static",SyntaxToken.KEYWORD1);
			cKeywords.add("volatile",SyntaxToken.KEYWORD1);
			cKeywords.add("break",SyntaxToken.KEYWORD1);
			cKeywords.add("case",SyntaxToken.KEYWORD1);
			cKeywords.add("continue",SyntaxToken.KEYWORD1);
			cKeywords.add("default",SyntaxToken.KEYWORD1);
			cKeywords.add("do",SyntaxToken.KEYWORD1);
			cKeywords.add("else",SyntaxToken.KEYWORD1);
			cKeywords.add("for",SyntaxToken.KEYWORD1);
			cKeywords.add("goto",SyntaxToken.KEYWORD1);
			cKeywords.add("if",SyntaxToken.KEYWORD1);
			cKeywords.add("return",SyntaxToken.KEYWORD1);
			cKeywords.add("sizeof",SyntaxToken.KEYWORD1);
			cKeywords.add("switch",SyntaxToken.KEYWORD1);
			cKeywords.add("while",SyntaxToken.KEYWORD1);
			cKeywords.add("asm",SyntaxToken.KEYWORD2);
			cKeywords.add("asmlinkage",SyntaxToken.KEYWORD2);
			cKeywords.add("far",SyntaxToken.KEYWORD2);
			cKeywords.add("huge",SyntaxToken.KEYWORD2);
			cKeywords.add("inline",SyntaxToken.KEYWORD2);
			cKeywords.add("near",SyntaxToken.KEYWORD2);
			cKeywords.add("pascal",SyntaxToken.KEYWORD2);
			cKeywords.add("true",SyntaxToken.LITERAL2);
			cKeywords.add("false",SyntaxToken.LITERAL2);
			cKeywords.add("NULL",SyntaxToken.LITERAL2);
		}
		return cKeywords;
	}

	// private members
	private static KeywordMap cKeywords;

	private boolean cpp;
	private KeywordMap keywords;
	private int lastOffset;
	private int lastKeyword;

	private boolean doKeyword(Segment line, int i, char c)
	{
		int i1 = i+1;

		int len = i - this.lastKeyword;
		byte id = this.keywords.lookup(line,this.lastKeyword,len);
		if(id != SyntaxToken.NULL)
		{
			if(this.lastKeyword != this.lastOffset)
				this.addToken(this.lastKeyword - this.lastOffset,SyntaxToken.NULL);
			this.addToken(len,id);
			this.lastOffset = i;
		}
		this.lastKeyword = i1;
		return false;
	}
}
