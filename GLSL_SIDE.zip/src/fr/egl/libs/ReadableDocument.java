/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */package fr.egl.libs;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.net.URL;
import java.util.Collections;
import java.util.Vector;
import java.util.zip.InflaterInputStream;
import java.util.zip.ZipException;


public class ReadableDocument {


	Vector<String> lines ;
	int readIndex;


	public void rewind(){ readIndex = 0; }


	public void rewind(float percent){ readIndex = (int)(lines.size()*percent); }


	public int getRemaining() {
		return lines.size()-1-readIndex;
	}


	public static ReadableDocument unzipAndBuild(String fileName){
		return build(fileName,false,true);
	}

	public static ReadableDocument build(String fileName){
		return build(fileName,false,false);
	}


	public static ReadableDocument unzipAndBuild(String fileName,boolean forceLocal){
		return build(fileName,forceLocal,true);
	}


	public static ReadableDocument build(String fileName,boolean forceLocal){
		return build(fileName,forceLocal,false);
	}

	public static ReadableDocument build(String fileName,boolean forceLocal, boolean unzip){



		ReadableDocument res = new ReadableDocument();

		res.lines = new Vector<String>();


		InputStreamReader flog	= null;
		LineNumberReader llog	= null;
		String myLine		     = null;
		try{

			
				if (unzip)
					flog = new InputStreamReader(new InflaterInputStream(new FileInputStream(new File(fileName)) ));
				else
					flog = new InputStreamReader(new FileInputStream(new File(fileName)) );


			llog = new LineNumberReader(flog);
			while ((myLine = llog.readLine()) != null) {
				res.lines.add(myLine);
			}

			flog.close();
			llog.close();
		}
		catch (Exception e){
		}
		res.readIndex = 0;

		return res;
	}



	public static ReadableDocument build(URL url){



		ReadableDocument res = new ReadableDocument();

		res.lines = new Vector<String>();


		InputStreamReader flog	= null;
		LineNumberReader llog	= null;
		String myLine		     = null;
		try{

			flog = new InputStreamReader(url.openStream() );

			llog = new LineNumberReader(flog);
			while ((myLine = llog.readLine()) != null) {
				res.lines.add(myLine);
			}

			flog.close();
			llog.close();
		}
		catch (Exception e){
			System.err.println("ERRORRRRRRRRRRRRRRRRR in Readable Docuement ");
			e.printStackTrace();
		}
		res.readIndex = 0;

		return res;
	}

	/*
	 * 

	 */
	public boolean hasMoreLine(){

		return (readIndex<lines.size());

	}

	public String getNextLine(){
		if (readIndex>=lines.size())
			return null;
		readIndex+=1;
		return lines.get(readIndex-1);
	}

	public void getOneLineBack(){
		readIndex --;
	}

	public int getCurrentLine(){
		return readIndex;
	}

	public void dispose(){
		lines.clear();
	}

	public int getLineCount() {
		return lines.size();
	}

	public String getAsString(){
		String res= "";
		for(String s : lines){
			res += s+"\n";
		}
		return res;
	}



	public static String unzipAndGetAsString(File f) {
		return getAsString(f,true);
	}

	public static String unzipAndGetAsString(String f) {
		return getAsString(new File(f),true);
	}


	public static String getAsString(String f) {
		return getAsString(new File(f),false);
	}

	public static String getAsString(File f) {
		return getAsString(f,false);
	}

	public static String getAsString(String f, boolean unzip) {
		return getAsString(new File(f),unzip);
	}

	public static String getAsString(File f, boolean unzip) {


		StringBuilder sr = new StringBuilder();

		try {

			InputStream stream  = new FileInputStream(f);

			InputStream Rstream  = new BufferedInputStream(  stream );

			if (unzip)
				Rstream = new BufferedInputStream( new InflaterInputStream(stream) );


			int head = 
					(0x000000FF & stream.read())<<16 |
					(0x000000FF & stream.read())<<8 |
					(0x000000FF & stream.read()) ;

			if (head != 0xEFBBBF){ // UTF8 HEADER				
				stream.close();

				Rstream  = new BufferedInputStream( stream  = new FileInputStream(f));

				if (unzip)
					Rstream = new BufferedInputStream( new InflaterInputStream(stream) );
			}

			if (unzip){
				// WHEN USING InflaterInputStream,  stream.available() returns 1 or 0 at EOF !!!!
				
				int count = 0;
				int a = 0;
				while ((a = Rstream.read()) != -1){
					sr.append((char) a);
					count ++ ;
				}

				//System.out.println("READ "+(unzip ? " UNZIPPED " : " ")+": " + count);

			}else{

				int count = Rstream.available();
				
				byte[] table = new byte[count];

				//System.out.println("READ "+(unzip ? " UNZIPPED " : " ")+": " + count);

				Rstream.read(table);			


				for(byte b : table)
					sr.append((char) b);	
			}

			stream.close();

		}catch (ZipException e) {
			
		} catch (Exception e) {
			e.printStackTrace();
		}


		return sr.toString();

	}


	// 1343

	/*

		long t = EGL_Utils.currentTimeMillis();
		String res = "";

		try {

			FileInputStream stream  = new FileInputStream(f);

			stream.read();
			stream.read();
			stream.read();

			while (stream.available()>0)				
				res += (char)stream.read();						

		} catch (Exception e) {
			e.printStackTrace();
		}



		System.out.println(EGL_Utils.currentTimeMillis() - t);
		return res;
	 */
	public static void main(String[] args) {
		System.out.println(getAsString(new File("../MARC-Framework/data/MARC/Model_Simon/library_appraisals/expectedness.-70.bml")));
	}


	public static void writeFromString(File folder, String all) {
		
		try{
			PrintStream fos = new PrintStream(new BufferedOutputStream(new FileOutputStream(folder)));
			fos.print(all);
			fos.close();
		} catch(Exception es) {
			es.printStackTrace();
			
		}
	}


	public void revertLines() {
		 Collections.reverse(lines);		
	}





}
