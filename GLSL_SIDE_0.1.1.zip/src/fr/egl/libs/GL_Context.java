/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.libs;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL20.GL_SHADING_LANGUAGE_VERSION;

import java.awt.GraphicsEnvironment;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.JOptionPane;

import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.AWTGLCanvas;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.PixelFormat;

import fr.egl.glsl_editor.MainEditor;

public class GL_Context  extends AWTGLCanvas  {


	private static final long serialVersionUID = 1L;

	public GL_Context() throws LWJGLException {

		super(GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice(),
				 new PixelFormat(),	Display.getDrawable());

		this.setFocusTraversalKeysEnabled(false);

	}

	
	public void releaseContext() throws LWJGLException{
		super.releaseContext();
	}
	
	public static int GLVersion = 330;
	public static int GLSLVersion = 330;
	public static String GLVersion_Description = "3.3.0";
	public static String GLSLVersion_Description = "3.3.0";

	public void initGL(){

		try {

			super.initGL();

			
			GLVersion_Description = glGetString(GL_VERSION);
			GLVersion = Integer.valueOf(GLVersion_Description.replace(".", "").split(" ")[0]);
			GLSLVersion_Description = glGetString(GL_SHADING_LANGUAGE_VERSION);
			GLSLVersion = Integer.valueOf(GLSLVersion_Description.replace(".", "").split(" ")[0]);


		}catch(Exception e){
			JOptionPane.showMessageDialog(MainEditor.frame, "GL Context can't be created. Exiting...");
			System.exit(0);
		}
		
		new Timer().schedule(new TimerTask() {			

			public void run() {
				GL_Context.super.repaint();					
			}
		}, 500, 500);

	}
	
	public void paintGL() {

		synchronized (this) {

			try{
				//GL11.glClearColor(0.85f,0.95f,0.05f,1);
				//GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
				synchronized (r){
					while (!r.isEmpty())
						r.remove(0).run();
				}
				//GL11.glClearColor(0.85f,0.95f,0.85f,1);
				//GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
				//swapBuffers();

			} catch (Exception e){
				/* TODO */
			}	
		}

	}

	Vector<Runnable> r = new Vector<>();

	public void addWaitingMethod(Runnable  object) {
		synchronized (r){
			r.add(object);
		}
			
	}


}
