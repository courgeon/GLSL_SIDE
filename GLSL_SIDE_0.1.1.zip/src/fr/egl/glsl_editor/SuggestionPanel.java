package fr.egl.glsl_editor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.BadLocationException;

import fr.egl.widgets.code_editor.JCodeTextArea;
import fr.egl.widgets.code_editor.syntax.GLSL_Syntax;


public class SuggestionPanel {
	

    	private static SuggestionPanel suggestion;
	
        private JList list;
        private JPopupMenu popupMenu;
        private String subWord;
        private final int insertionPosition;
        
        private JCodeTextArea textarea;

        public SuggestionPanel(JCodeTextArea textarea, int position, String subWord, Point location) throws Exception {

            list = createSuggestionList(textarea.getShaderInUni(),position, subWord);
            if (list == null)
            	throw new Exception("NothingToSuggest");
            		
            this.insertionPosition = position;
            this.subWord = subWord;
            this.textarea = textarea;
            popupMenu = new JPopupMenu();
            popupMenu.removeAll();
            popupMenu.setOpaque(false);
            popupMenu.setBorder(null);
            popupMenu.add(list , BorderLayout.CENTER);
            popupMenu.show(textarea, location.x, textarea.getBaseline(0, 0) + location.y);
             
        }
        
        public static boolean keyTyped(JCodeTextArea textarea, KeyEvent e) {
            if (e.getKeyChar() == KeyEvent.VK_ENTER) {
                if (suggestion != null) {
                    if (suggestion.insertSelection()) {
                        e.consume();
                        final int position = textarea.getCaretPosition();
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    textarea.getDocument().remove(position - 1, 1);
                                } catch (BadLocationException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        return true;
                    }
                }
            }
            return false;
        }
        public static boolean keyReleased(JCodeTextArea textarea,KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_DOWN && suggestion != null) {
                suggestion.moveDown();
                return true;
            } else if (e.getKeyCode() == KeyEvent.VK_UP && suggestion != null) {
                suggestion.moveUp();
                return true;
            } else if (Character.isWhitespace(e.getKeyChar())) {
                hideSuggestion();
                return false;
            }
            return false;
        }
        
        public static void showSuggestionLater(final JCodeTextArea textarea ) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    showSuggestion(textarea);
                }

            });
        }

        protected static void showSuggestion(final JCodeTextArea textarea) {
        	
            hideSuggestion();
            final int position = textarea.getCaretPosition();
            Point location  = textarea.getCaretLocation();
           
            String text = textarea.getText();
            int start = Math.max(0, position - 1);
            while (start > 0) {
                if (!Character.isWhitespace(text.charAt(start))) {
                    start--;
                } else {
                    start++;
                    break;
                }
            }
            if (start > position) {
                return;
            }
            final String subWord = text.substring(start, position);
            if (subWord.length() < 2) {
                return;
            }
            try{
	            suggestion = new SuggestionPanel(textarea, position, subWord, location);
	            SwingUtilities.invokeLater(new Runnable() {
	                @Override
	                public void run() {
	                    textarea.requestFocusInWindow();
	                }
	            });
            }catch(Exception e){
            	// NOTHING TO SUGGEST
            }
        }

        public static boolean isVisible(){
        	return suggestion!= null && suggestion.popupMenu != null && suggestion.popupMenu.isVisible();
        }
        
        public void hide() {
            popupMenu.setVisible(false);
            if (suggestion == this) {
                suggestion = null;
            }
        }

        private JList createSuggestionList(Vector<String> variable, final int position, final String subWord) {
            Vector<String> possiblities = new Vector<>();

            String subWordlc = subWord.toLowerCase();
            
            System.out.println("Suggesting with variables : " + variable.size());
            
            for(String s : variable) if (s.toLowerCase().startsWith(subWordlc)) 				possiblities.add("<html><b><font color='#555555'> "+s+" </font></b></html>");
            for(String s : GLSL_Syntax.Functions) if (s.toLowerCase().startsWith(subWordlc)) 	possiblities.add("<html><b><font color='#3388AA'> "+s+" </font></b></html>");
            for(String s : GLSL_Syntax.Keywords) if (s.toLowerCase().startsWith(subWordlc)) 	possiblities.add("<html><b><font color='#0000FF'> "+s+" </font></b></html>");
            for(String s : GLSL_Syntax.Types) if (s.toLowerCase().startsWith(subWordlc)) 		possiblities.add("<html><b><font color='#811044'> "+s+" </font></b></html>");
            for(String s : GLSL_Syntax.EGL_Keywords) if (s.toLowerCase().startsWith(subWordlc)) possiblities.add("<html><b><font color='#3017b3'> "+s+" </font></b></html>");

            for(String s : variable) if (!s.toLowerCase().startsWith(subWordlc)&&s.toLowerCase().contains(subWordlc)) 					possiblities.add("<html><font color='#555555'> "+s+" </font></html>");
            for(String s : GLSL_Syntax.Functions) if (!s.toLowerCase().startsWith(subWordlc)&&s.toLowerCase().contains(subWordlc)) 		possiblities.add("<html><font color='#3388AA'> "+s+" </font></html>");
            for(String s : GLSL_Syntax.Keywords) if (!s.toLowerCase().startsWith(subWordlc)&&s.toLowerCase().contains(subWordlc)) 		possiblities.add("<html><font color='#0000FF'> "+s+" </font></html>");
            for(String s : GLSL_Syntax.Types) if (!s.toLowerCase().startsWith(subWordlc)&&s.toLowerCase().contains(subWordlc)) 			possiblities.add("<html><font color='#811044'> "+s+" </font></html>");
            for(String s : GLSL_Syntax.EGL_Keywords) if (!s.toLowerCase().startsWith(subWordlc)&&s.toLowerCase().contains(subWordlc)) 	possiblities.add("<html><font color='#3017b3'> "+s+" </font></html>");
            
            Object [] data = possiblities.toArray();
            
            if (data.length == 0)
				return null;
            
            
            JList<Object> list = new JList<Object> (data);
            list.setMinimumSize(new Dimension(200, 10));
            list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            list.setSelectedIndex(0);
            list.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        insertSelection();
                    }
                }
            });
            return list;
        }

        public boolean insertSelection() {
            if (list.getSelectedValue() != null) {
                try {
                    String selectedSuggestion = ((String) list.getSelectedValue());
                    selectedSuggestion = selectedSuggestion.split(" ")[2]; // removing HTML Stuff !
                    textarea.getDocument().remove(insertionPosition-subWord.length(), subWord.length()); // removing already typed in text
                    textarea.getDocument().insertString(insertionPosition-subWord.length(), selectedSuggestion, null);
                    return true;
                } catch (BadLocationException e1) {
                    e1.printStackTrace();
                }
                hideSuggestion();
            }
            return false;
        }

        

        public static void hideSuggestion() {
            if (suggestion != null) {
                suggestion.hide();
                suggestion = null;
            }
        }
        
        public void moveUp() {
            int index = Math.max(list.getSelectedIndex() - 1, 0);
            selectIndex(index);
        }

        public void moveDown() {
            int index = Math.min(list.getSelectedIndex() + 1, list.getModel().getSize() - 1);
            selectIndex(index);
        }

        private void selectIndex(int index) {
            final int position = textarea.getCaretPosition();
            list.setSelectedIndex(index);
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    textarea.setCaretPosition(position);
                };
            });
        }
    }