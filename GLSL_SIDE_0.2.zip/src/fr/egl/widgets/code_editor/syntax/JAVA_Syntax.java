
/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */


package fr.egl.widgets.code_editor.syntax;

import fr.egl.widgets.code_editor.KeywordMap;

/**
 * Java token marker.
 *
 * @author Slava Pestov
 * @version $Id: JavaTokenMarker.java,v 1.5 1999/12/13 03:40:30 sp Exp $
 */
public class JAVA_Syntax extends C_Syntax
{
	public JAVA_Syntax()
	{
		super(false,getKeywords());
	}

	public static KeywordMap getKeywords()
	{
		if(javaKeywords == null)
		{
			javaKeywords = new KeywordMap(false);
			javaKeywords.add("package",SyntaxToken.KEYWORD2);
			javaKeywords.add("import",SyntaxToken.KEYWORD2);
			javaKeywords.add("byte",SyntaxToken.KEYWORD3);
			javaKeywords.add("char",SyntaxToken.KEYWORD3);
			javaKeywords.add("short",SyntaxToken.KEYWORD3);
			javaKeywords.add("int",SyntaxToken.KEYWORD3);
			javaKeywords.add("long",SyntaxToken.KEYWORD3);
			javaKeywords.add("float",SyntaxToken.KEYWORD3);
			javaKeywords.add("double",SyntaxToken.KEYWORD3);
			javaKeywords.add("boolean",SyntaxToken.KEYWORD3);
			javaKeywords.add("void",SyntaxToken.KEYWORD3);
			javaKeywords.add("class",SyntaxToken.KEYWORD3);
			javaKeywords.add("interface",SyntaxToken.KEYWORD3);
			javaKeywords.add("abstract",SyntaxToken.KEYWORD1);
			javaKeywords.add("final",SyntaxToken.KEYWORD1);
			javaKeywords.add("private",SyntaxToken.KEYWORD1);
			javaKeywords.add("protected",SyntaxToken.KEYWORD1);
			javaKeywords.add("public",SyntaxToken.KEYWORD1);
			javaKeywords.add("static",SyntaxToken.KEYWORD1);
			javaKeywords.add("synchronized",SyntaxToken.KEYWORD1);
			javaKeywords.add("native",SyntaxToken.KEYWORD1);
			javaKeywords.add("volatile",SyntaxToken.KEYWORD1);
			javaKeywords.add("transient",SyntaxToken.KEYWORD1);
			javaKeywords.add("break",SyntaxToken.KEYWORD1);
			javaKeywords.add("case",SyntaxToken.KEYWORD1);
			javaKeywords.add("continue",SyntaxToken.KEYWORD1);
			javaKeywords.add("default",SyntaxToken.KEYWORD1);
			javaKeywords.add("do",SyntaxToken.KEYWORD1);
			javaKeywords.add("else",SyntaxToken.KEYWORD1);
			javaKeywords.add("for",SyntaxToken.KEYWORD1);
			javaKeywords.add("if",SyntaxToken.KEYWORD1);
			javaKeywords.add("instanceof",SyntaxToken.KEYWORD1);
			javaKeywords.add("new",SyntaxToken.KEYWORD1);
			javaKeywords.add("return",SyntaxToken.KEYWORD1);
			javaKeywords.add("switch",SyntaxToken.KEYWORD1);
			javaKeywords.add("while",SyntaxToken.KEYWORD1);
			javaKeywords.add("throw",SyntaxToken.KEYWORD1);
			javaKeywords.add("try",SyntaxToken.KEYWORD1);
			javaKeywords.add("catch",SyntaxToken.KEYWORD1);
			javaKeywords.add("extends",SyntaxToken.KEYWORD1);
			javaKeywords.add("finally",SyntaxToken.KEYWORD1);
			javaKeywords.add("implements",SyntaxToken.KEYWORD1);
			javaKeywords.add("throws",SyntaxToken.KEYWORD1);
			javaKeywords.add("this",SyntaxToken.LITERAL2);
			javaKeywords.add("null",SyntaxToken.LITERAL2);
			javaKeywords.add("super",SyntaxToken.LITERAL2);
			javaKeywords.add("true",SyntaxToken.LITERAL2);
			javaKeywords.add("false",SyntaxToken.LITERAL2);
		}
		return javaKeywords;
	}

	// private members
	private static KeywordMap javaKeywords;
}
