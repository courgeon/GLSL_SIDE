package fr.egl.widgets.code_editor.syntax;
/*
 * JavaTokenMarker.java - Java token marker
 * Copyright (C) 1999 Slava Pestov
 *
 * You may use and modify this package for any purpose. Redistribution is
 * permitted, in both source and binary form, provided that this notice
 * remains intact in all source distributions of this package.
 */


import fr.egl.widgets.code_editor.KeywordMap;


/**
 * Java token marker.
 *
 * @author Slava Pestov
 * @version $Id: JavaTokenMarker.java,v 1.5 1999/12/13 03:40:30 sp Exp $
 */
public class GLSL_Syntax extends C_Syntax
{
	public GLSL_Syntax()
	{
		super(false,getKeywords());
	}
	
	public  static String [] Keywords = new String[]{ "gl_FragCoord", "gl_Position", "gl_FragDepth", "attribute", "invariant","precise", "discard","return", "const", "uniform", "varying", "buffer", "shared", "coherent", "volatile", "restrict", "readonly", "writeonly", "atomic_uint", "layout", "centroid", "flat", "smooth", "noperspective", "patch", "sample", "break", "continue", "do", "for", "while", "switch", "case", "default", "if", "else", "subroutine", "in", "out", "inout", "lowp", "mediump", "highp", "struct", "common", "partition", "active", "asm", "class", "union", "enum", "typedef", "template", "this", "resource", "goto", "inline", "noinline", "public", "static", "extern", "external", "interface", "fixed", "unsigned", "superp", "input", "output", "filter", "sizeof", "cast", "namespace", "using"};
	public  static String [] Functions = new String[]{ "radians","degrees","sin","cos","tan","asin","atan","acos","sinh","cosh","tanh","asinh","acosh","atanh","pow","exp","log","exp2","log2","sqrt","inversesqrt","abs","sign","floor","trunc","round","ceil","roundEven","fract","mod","modf","min","max","clamp","mix","step","smoothstep","isnan","ising","floatBitsToInt","intBitToFloat","fma","frexp","idexp","packUnorm2x16","packSnorm2x16","packUnorm4x8","packSnorm4x8","packDouble2x32","unpackDouble2x32","packHalf2x16","unpackHalf2x16","length","distance","cross","dot","normalize","ftransform","faceforward","reflect","refract","matrixCompMult","outerProduct","transpose","determinant","inverse","lessThan","lessThanEqual","greaterThan","greaterThanEqual","equal","notEqual","any","all","not","textureSize","texture","textureQueryLod","textureQueryLevels","textureProj","textureOffset","texelFetch","textureLod","texelFetchOffset","textureProjOffset","textureLodOffset","textureProjLod","textureProjLodOffset","textureGrad","textureGradOffset","textureProjGrad","textureProjGradOffset","textureGather","textureGatherOffset","textureGatherOffsets","textureCube","shadow1D","shadow2D","shadow1DProj","shadow2DProj","shadow1DLod","shadow2DLod","shadow1DProjLod","shadow2DProjLod","atomicCounterIncrement","atomicCounterDecrement","atomicCounter","atomicAdd","atomicMin","atomicMax","atomicAnd","atomicOr","atomicXor","atomicExchange","atomicCompSwap","imageSize","imageLoad","imageStore","imageAtomicAdd","imageAatomicAdd","imageAtomicMin","imageAtomicMax","imageAtomicAnd","imageAtomicOr","imageAtomicXor","imageAtomicExchange","imageAtomicCompSwap","dFdx","dFdy","fwidth","interpolateAtCentroid","interpolateAtSample","interpolateAtOffset","noise1","noise2","noise3","noise4","EmitStreamVertex","EmitStreamPrimitive","EmitVertex","EmitPrimitive","barrier","memoryBarrier","memoryBarrierAtomicCounter","memoryBarrierBuffer","memoryBarrierShared","memoryBarrierImage","groupMemoryBarrier"};
	public  static String [] Types = new String[]{ "true","false","float","double","int","void","bool","mat2","mat3","mat4","dmat2","dmat3","dmat4","mat2x2","mat2x3","mat2x4","dmat2x2","dmat2x3","dmat2x4","mat3x2","mat3x3","mat3x4","dmat3x2","dmat3x3","dmat3x4","mat4x2","mat4x3","mat4x4","dmat4x2","dmat4x3","dmat4x4","vec2","vec3","vec4","ivec2","ivec3","ivec4","bvec2","bvec3","bvec4","dvec2","dvec3","dvec4","uint","uvec2","uvec3","uvec4","precision","sampler1D","sampler2D","sampler3D","samplerCube","sampler1DShadow","sampler2DShadow","samplerCubeShadow","sampler1DArray","sampler2DArray","sampler1DArrayShadow","sampler2DArrayShadow","isampler1D","isampler2D","isampler3D","isamplerCube","isampler1DArray","isampler2DArray","usampler1D","usampler2D","usampler3D","usamplerCube","usampler1DArray","usampler2DArray","sampler2DRect","sampler2DRectShadow","isampler2DRect","usampler2DRect","samplerBuffer","isamplerBuffer","usamplerBuffer","sampler2DMS","isampler2DMS","usampler2DMS","sampler2DMSArray","isampler2DMSArray","usampler2DMSArray","samplerCubeArray","samplerCubeArrayShadow","isamplerCubeArray","usamplerCubeArray","image1D","iimage1D","uimage1D","image2D","iimage2D","uimage2D","image3D","iimage3D","uimage3D","image2DRect","iimage2DRect","uimage2DRect","imageCube","iimageCube","uimageCube","imageBuffer","iimageBuffer","uimageBuffer","image1DArray","iimage1DArray","uimage1DArray","image2DArray","iimage2DArray","uimage2DArray","imageCubeArray","iimageCubeArray","uimageCubeArray","image2DMS","iimage2DMS","uimage2DMS","image2DMSArray","iimage2DMSArray","uimage2DMSArray","long","short","half","hvec2","hvec3","hvec4","fvec2","fvec3","fvec4","sampler3DRect"};
	public  static String [] EGL_Keywords = new String[]{ "CurrentTime","world2model","model2world","world2camera","world2light","light_projection","camera2world","projection","CameraExposure","L_Properties","L_Positions","L_Directions","L_count","ambient_colors","autoexpose","light_cast_shadow","shadowFadeScale" };
	
	public static KeywordMap getKeywords()
	{
		if(glslKeywords == null)
		{
			glslKeywords = new KeywordMap(false);
			
			/// YEAH, I KNOW, THESE SHOULD BE OUTSIDE SOURCE CODE... I'LL DO IT, SOMEDAY :)
			
			for(String s : Keywords)
				glslKeywords.add(s,SyntaxToken.KEYWORD1);
			for(String s : Functions)
				glslKeywords.add(s,SyntaxToken.KEYWORD2);
			for(String s : Types)
				glslKeywords.add(s,SyntaxToken.KEYWORD3);
			for(String s : EGL_Keywords)
				glslKeywords.add(s,SyntaxToken.LITERAL1);
			 
		}
		return glslKeywords;
	}

	// private members
	private static KeywordMap glslKeywords;
}
