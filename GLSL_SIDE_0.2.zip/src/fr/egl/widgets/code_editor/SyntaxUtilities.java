/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */


package fr.egl.widgets.code_editor;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.text.Segment;
import javax.swing.text.TabExpander;
import javax.swing.text.Utilities;

import fr.egl.widgets.code_editor.syntax.SyntaxToken;

/**
 * Class with several utility functions used by jEdit's syntax colorizing
 * subsystem.
 */
public class SyntaxUtilities
{
	/**
	 * Checks if a subregion of a <code>Segment</code> is equal to a
	 * string.
	 * @param ignoreCase True if case should be ignored, false otherwise
	 * @param text The segment
	 * @param offset The offset into the segment
	 * @param match The string to match
	 */
	public static boolean regionMatches(boolean ignoreCase, Segment text,
			int offset, String match)
	{
		int length = offset + match.length();
		char[] textArray = text.array;
		if(length > text.offset + text.count)
			return false;
		for(int i = offset, j = 0; i < length; i++, j++)
		{
			char c1 = textArray[i];
			char c2 = match.charAt(j);
			if(ignoreCase)
			{
				c1 = Character.toUpperCase(c1);
				c2 = Character.toUpperCase(c2);
			}
			if(c1 != c2)
				return false;
		}
		return true;
	}

	/**
	 * Checks if a subregion of a <code>Segment</code> is equal to a
	 * character array.
	 * @param ignoreCase True if case should be ignored, false otherwise
	 * @param text The segment
	 * @param offset The offset into the segment
	 * @param match The character array to match
	 */
	public static boolean regionMatches(boolean ignoreCase, Segment text,
			int offset, char[] match)
	{
		int length = offset + match.length;
		char[] textArray = text.array;
		if(length > text.offset + text.count)
			return false;
		for(int i = offset, j = 0; i < length; i++, j++)
		{
			char c1 = textArray[i];
			char c2 = match[j];
			if(ignoreCase)
			{
				c1 = Character.toUpperCase(c1);
				c2 = Character.toUpperCase(c2);
			}
			if(c1 != c2)
				return false;
		}
		return true;
	}

	/**
	 * Returns the default style table. This can be passed to the
	 * <code>setStyles()</code> method of <code>SyntaxDocument</code>
	 * to use the default syntax styles.
	 */
	public static SyntaxStyle[] getDefaultSyntaxStyles()
	{
		SyntaxStyle[] styles = new SyntaxStyle[SyntaxToken.ID_COUNT];

		styles[SyntaxToken.COMMENT1] = new SyntaxStyle(new Color(0x008833),true,false);
		styles[SyntaxToken.COMMENT2] = new SyntaxStyle(new Color(0x008899),true,false);
		styles[SyntaxToken.KEYWORD1] = new SyntaxStyle(new Color(0x3388AA),false,true);
		styles[SyntaxToken.KEYWORD2] = new SyntaxStyle(new Color(0x0000FF),false,true);
		styles[SyntaxToken.KEYWORD3] = new SyntaxStyle(new Color(0x811044),false,true);
		styles[SyntaxToken.LITERAL1] = new SyntaxStyle(new Color(0x3017b3),false,true);
		styles[SyntaxToken.LITERAL2] = new SyntaxStyle(new Color(0x30FFb3),false,true);
		styles[SyntaxToken.LABEL]    = new SyntaxStyle(new Color(0x990033),false,true);
		styles[SyntaxToken.OPERATOR] = new SyntaxStyle(Color.black,false,true);
		styles[SyntaxToken.INVALID]  = new SyntaxStyle(Color.red,false,true);
		styles[SyntaxToken.HIGHLIGHT] = new SyntaxStyle(new Color(0x228855),false,true, new Color(0xAAEECC));

		return styles;
	}

	/**
	 * Paints the specified line onto the graphics context. Note that this
	 * method munges the offset and count values of the segment.
	 * @param line The line segment
	 * @param tokens The token list for the line
	 * @param styles The syntax style list
	 * @param expander The tab expander used to determine tab stops. May
	 * be null
	 * @param gfx The graphics context
	 * @param x The x co-ordinate
	 * @param y The y co-ordinate
	 * @return The x co-ordinate, plus the width of the painted string
	 */
	public static int paintSyntaxLine(Segment line, SyntaxToken tokens,
			SyntaxStyle[] styles, TabExpander expander, Graphics gfx,
			int x, int y)
	{
		Font defaultFont = gfx.getFont();
		Color defaultColor = gfx.getColor();

		for(;;)
		{
			byte id = tokens.id;
			if(id == SyntaxToken.END)
				break;

			int length = tokens.length;
			
			if(id == SyntaxToken.NULL)
			{
				
				if(!defaultColor.equals(gfx.getColor()))
					gfx.setColor(defaultColor);
				if(!defaultFont.equals(gfx.getFont()))
					gfx.setFont(defaultFont);
				
			}
			else{
				
				styles[id].setGraphicsFlags(gfx,defaultFont);
			}

			line.count = length;
			
			int sx=x;
			
			x = Utilities.drawTabbedText(line,x,y,gfx,expander,0);
			
			if(id == SyntaxToken.HIGHLIGHT){
				gfx.setColor(styles[id].getBackground());
				int h = gfx.getFontMetrics().getHeight();
				gfx.fillRect(sx-4, (int)(y-h*0.70), x-sx+8, h);
				styles[id].setGraphicsFlags(gfx,defaultFont);
				x = Utilities.drawTabbedText(line,sx,y,gfx,expander,0);
			}

			
			line.offset += length;
			tokens = tokens.next;
		}

		return x;
	}

	// private members
	private SyntaxUtilities() {}
}
