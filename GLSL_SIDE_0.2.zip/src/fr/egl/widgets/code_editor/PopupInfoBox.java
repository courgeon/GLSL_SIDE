/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.widgets.code_editor;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class PopupInfoBox extends JDialog  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel label ;

	public PopupInfoBox(){
		this.label = new JLabel();
		this.getContentPane().setLayout(new BorderLayout());
		this.label.setBackground(new Color(255,255,200));
		this.label.setOpaque(true);
		this.getContentPane().add(new JScrollPane(this.label));
		this.setBounds(0,0,400,100);
		this.setFocusable(false);
		this.setUndecorated(true);
		this.setAlwaysOnTop(true);
	}

	public void show(int x, int y, String message){

		this.label.setText("<html>"+message.trim().replace(">", "&gt;").replace("<", "&lt;").replace("\n", "<br/>")+"</html>");
		this.setLocation(x, y);
		if (!this.isVisible())
			this.pack();
		this.setVisible(true);
	}

	public void showHTML(int x, int y, String message){
		this.label.setText(message);
		this.setLocation(x, y);
		if (!this.isVisible())
			this.pack();
		this.setVisible(true);
	}

}
