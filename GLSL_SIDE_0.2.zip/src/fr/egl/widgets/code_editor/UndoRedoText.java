/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.widgets.code_editor;

import java.util.Vector;


public class UndoRedoText {

	Vector<String> undoStack = new Vector<String>();
	Vector<String> redoStack = new Vector<String>();

	JCodeTextArea Editor ;

	public UndoRedoText(JCodeTextArea editor){
		this.Editor = editor;
	}

	Thread changeNotifier = null;

	String currentText = null;


	public void undo(){
		if (this.undoStack.size()>0){
			this.redoStack.add(this.Editor.getText());
			this.Editor.setText(this.undoStack.remove(this.undoStack.size()-1));
		}
	}
	public void redo(){
		if (this.redoStack.size()>0){
			this.undoStack.add(this.Editor.getText());
			this.Editor.setText(this.redoStack.remove(this.redoStack.size()-1));
		}
	}

	public void modified() {

		if (this.changeNotifier != null)
			this.changeNotifier.interrupt();

		this.changeNotifier = new Thread() {
			@Override
			public void run(){
				try{
					System.out.println("Mod text");
					Thread.sleep(300);
					if (UndoRedoText.this.currentText != null)
						UndoRedoText.this.undoStack.add(UndoRedoText.this.currentText);
					UndoRedoText.this.redoStack.clear();
					UndoRedoText.this.currentText = UndoRedoText.this.Editor.getText();


					if (UndoRedoText.this.undoStack.size()>150){
						UndoRedoText.this.undoStack.remove(0);
					}
				}catch(Exception e){

				}
			}
		};
		this.changeNotifier.start();
	}


}
