/*
 * Copyright (c) 2006-2013 Matthieu COURGEON and Adrien MAZAUD
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.net;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;


public class UDP_Server {



	private IP_Analyser Analyser;
	DatagramSocket s_in;
	UdpListener vcl;
	public UDP_Server(int in_port, IP_Analyser analys) throws Exception
	{
		Analyser = analys;
		s_in = new DatagramSocket(in_port);
		vcl = new UdpListener(s_in);
		vcl.start();	
	}

	private class UdpListener extends Thread
	{

		DatagramSocket s_in;
		private UdpListener(DatagramSocket sockin)
		{
			s_in = sockin;
		}

		@Override
		public void run()
		{
			int bufferSize = 1024*25;
			byte [] b = new byte[bufferSize];

			DatagramPacket dp = new DatagramPacket(b, b.length);

			try {
				s_in.setReceiveBufferSize(b.length);
			} catch (SocketException e) {  e.printStackTrace(); }

			while(true)
			{
				try
				{
					s_in.receive(dp);

					int recLen = dp.getLength();

					String s = new String(dp.getData(),0,recLen);

					try{
						Analyser.messageReceived( null, dp.getAddress().getHostAddress(),dp.getPort(), s);
					}catch(Exception e){ e.printStackTrace(); }

				}
				catch (Exception ex)
				{
					if (bufferSize<1024*1024){
						bufferSize *= 2;
						b = new byte[bufferSize];
						dp = new DatagramPacket(b, b.length);
					}
					ex.printStackTrace();
				}
			}
		}
	}


	public int getPort() {
		return s_in.getLocalPort();
	}

}
