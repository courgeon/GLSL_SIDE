/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.libs;

import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;

public class EGL_BufferManager {

	static final boolean useDirect = true;
	//	static public boolean CreationLOCKED = false;
	
	public static void freeBuffer(ByteBuffer buf){
	
	}

	public static DoubleBuffer allocateDoubleBuffer(int size){
		//		if (CreationLOCKED){
		//			int a = 5 / 0;
		//		}
		if (useDirect)
			return BufferUtils.createDoubleBuffer(size);
		else
			return DoubleBuffer.allocate(size);

	}

	public static DoubleBuffer allocateDoubleBuffer(double [] values){
		DoubleBuffer res = allocateDoubleBuffer(values.length);
		for(double f : values)
			res.put(f);
		res.rewind();
		return res;
	}


	public static double[] doubleArray(DoubleBuffer buffer) {

		buffer.rewind();
		int size = buffer.remaining();

		double [] res = new double[size];


		for(int i=0;i<size;i++)
			res[i] = buffer.get();

		return res;
	}



	public static FloatBuffer allocateFloatBuffer(int size){
		//		if (CreationLOCKED){
		//			int a = 5 / 0;
		//		}
		if (useDirect)
			return BufferUtils.createFloatBuffer(size);
		else
			return FloatBuffer.allocate(size);
	}


	public static FloatBuffer allocateFloatBuffer(float [] values){
		FloatBuffer res = allocateFloatBuffer(values.length);
		for(float f : values)
			res.put(f);
		res.rewind();
		return res;
	}

	public static float[] floatArray(FloatBuffer buffer, float[] target) {

		buffer.rewind();
		int size = buffer.remaining();

		for(int i=0;i<size;i++)
			target[i] = buffer.get();

		return target;
	}


	public static int[] intArray(IntBuffer buffer, int[] target ) {

		buffer.rewind();
		int size = buffer.remaining();

		for(int i=0;i<size;i++)
			target[i] = buffer.get();

		return target;
	}


	public static IntBuffer allocateIntBuffer(int size){
		//		if (CreationLOCKED){
		//			int a = 5 / 0;
		//		}
		if (useDirect )
			return BufferUtils.createIntBuffer(size);
		else
			return IntBuffer.allocate(size);
	}


	public static IntBuffer allocateIntBuffer(int [] values){
		IntBuffer res = allocateIntBuffer(values.length);
		for(int f : values)
			res.put(f);
		res.rewind();
		return res;
	}

	public static ByteBuffer allocateByteBuffer(byte [] values){
		ByteBuffer res = allocateByteBuffer(values.length);
		for(byte f : values)
			res.put(f);
		res.rewind();
		return res;
	}

	public static ByteBuffer allocateByteBuffer(float [] values){
		ByteBuffer res = allocateByteBuffer(values.length*4);
		for(float f : values)
			res.putFloat(f);
		res.rewind();
		return res;
	}
	
	public static ByteBuffer allocateByteBuffer(int size){
		if (useDirect)
			return BufferUtils.createByteBuffer(size);
		else
			return ByteBuffer.allocate(size);
	}

}
