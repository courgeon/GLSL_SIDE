package fr.egl.glsl_editor;

public interface SaveListener {

	public void setSaved(boolean saved);
}
