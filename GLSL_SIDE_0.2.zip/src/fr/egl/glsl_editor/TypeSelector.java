package fr.egl.glsl_editor;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TypeSelector {

	public static enum ShaderType{
		VERTEX ,
		TESS_CONT ,
		TESS_EVAL ,
		GEOMETRY ,
		FRAGMENT ,
		COMPUTE ;

		public String toString() {
			switch(this){
			case  VERTEX: return "Vertex Shader"; 
			case  TESS_CONT: return "Tesselation Control Shader"; 
			case  TESS_EVAL: return "Tesselation Evaluation Shader"; 
			case  GEOMETRY: return "Geometry Shader"; 
			case  FRAGMENT: return "Fragment Shader"; 
			case  COMPUTE: return "Compute Shader"; 
			}
			return "";
		}
	}; 

	static boolean validated = false;
	
	public static Vector<ShaderType> selectTypes(String fileName, Vector<String> sections){


		JFrame popup = new JFrame(fileName+ " : Shader stage : ");

		popup.setAlwaysOnTop(true);
		popup.getContentPane().setLayout(null);
		Vector<JComboBox<ShaderType>> types = new Vector<JComboBox<ShaderType>>();
		int i = 5;

		for(String sec : sections){
			JLabel n = new JLabel(sec+ " : ");
			n.setBounds(5,i,250,25);
			JComboBox<ShaderType> typesSelector = new JComboBox<ShaderType>();
			typesSelector.addItem(ShaderType.VERTEX);
			typesSelector.addItem(ShaderType.TESS_CONT);
			typesSelector.addItem(ShaderType.TESS_EVAL);
			typesSelector.addItem(ShaderType.GEOMETRY);
			typesSelector.addItem(ShaderType.FRAGMENT);
			typesSelector.addItem(ShaderType.COMPUTE);
			typesSelector.setBounds(260,i,250,25);
			types.add(typesSelector);
			popup.getContentPane().add(n);
			popup.getContentPane().add(typesSelector);
			
			if (sec.toLowerCase().contains("vertex")) typesSelector.setSelectedIndex(0);
			if (sec.toLowerCase().contains("vp")) typesSelector.setSelectedIndex(0);
			if (sec.toLowerCase().contains("vs")) typesSelector.setSelectedIndex(0);
			if (sec.toLowerCase().contains("tesselation_control")) typesSelector.setSelectedIndex(1);
			if (sec.toLowerCase().contains("tcs")) typesSelector.setSelectedIndex(2);
			if (sec.toLowerCase().contains("tcp")) typesSelector.setSelectedIndex(2);
			if (sec.toLowerCase().contains("tesselation_eval")) typesSelector.setSelectedIndex(2);
			if (sec.toLowerCase().contains("tes")) typesSelector.setSelectedIndex(2);
			if (sec.toLowerCase().contains("tep")) typesSelector.setSelectedIndex(2);
			if (sec.toLowerCase().contains("geometry")) typesSelector.setSelectedIndex(3);
			if (sec.toLowerCase().contains("gs")) typesSelector.setSelectedIndex(3);
			if (sec.toLowerCase().contains("gp")) typesSelector.setSelectedIndex(3);
			if (sec.toLowerCase().contains("fragment")) typesSelector.setSelectedIndex(4);
			if (sec.toLowerCase().contains("fs")) typesSelector.setSelectedIndex(4);
			if (sec.toLowerCase().contains("pixel")) typesSelector.setSelectedIndex(4);
			if (sec.toLowerCase().contains("ps")) typesSelector.setSelectedIndex(4);
			if (sec.toLowerCase().contains("cs")) typesSelector.setSelectedIndex(5);
			if (sec.toLowerCase().contains("compute")) typesSelector.setSelectedIndex(5);
			i+= 30;
		}

		JButton valide = new JButton("Valider");
		popup.getContentPane().add(valide);
		valide.setBounds(5,i+5,506,25);
		valide.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				validated = true; 
			}
		});
		

		validated = false;

		popup.setSize(new Dimension(540,i+85));
		popup.setLocationRelativeTo(MainEditor.frame);
		popup.setVisible(true);

		valide.requestFocus();
		while (!validated && popup.isVisible()){
			try {
				Thread.sleep(100);
			} catch (InterruptedException e1) {
			}
		}
		if (!popup.isVisible()) return null; 
		popup.dispose();

		Vector<ShaderType> res = new Vector<>();

		for(JComboBox<ShaderType> sel : types){
			res.add((ShaderType)sel.getSelectedItem());
		}

		return res;
	}


	public static Vector<ShaderType> selectNew( ){

		JFrame popup = new JFrame("Choisir les sections de Shader");

		popup.setAlwaysOnTop(true);
		popup.getContentPane().setLayout(null);
		
		int i = 5;

		Vector<JCheckBox> boxes = new Vector<>();
		for(ShaderType type : ShaderType.values()){
			JCheckBox box = new JCheckBox(type.toString());
			box.setBounds(5,i,506,25);
			i+= 30;
			boxes.add(box);
			popup.getContentPane().add(box);
		}

		JButton valide = new JButton("Valider");
		popup.getContentPane().add(valide);
		valide.setBounds(5,i+5,506,25);
		valide.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for (JCheckBox b : boxes)
					validated |= b.isSelected(); 
			}
		});
		

		validated = false;

		popup.setSize(new Dimension(540,i+85));
		popup.setLocationRelativeTo(MainEditor.frame);
		popup.setVisible(true);

		valide.requestFocus();
		while (!validated && popup.isVisible()){
			try {
				Thread.sleep(100);
			} catch (InterruptedException e1) {
			}
		}
		if (!popup.isVisible()) return null; 
		popup.dispose();
		Vector<ShaderType> types = new Vector<>();
		for(JCheckBox box : boxes){
			if (box.isSelected()){
				for(ShaderType type : ShaderType.values())
					if(box.getText().equals(type.toString()))
						types.addElement(type);
									
			}			
		}
		return types;
	}

}
