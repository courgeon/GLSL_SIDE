package fr.egl.glsl_editor;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.TransferHandler;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.tools.Diagnostic.Kind;

import org.lwjgl.LWJGLException;

import fr.egl.glsl_editor.TypeSelector.ShaderType;
import fr.egl.libs.GL_Context;
import fr.egl.libs.ReadableDocument;
import fr.egl.net.IP_Analyser;
import fr.egl.net.UDP_Client;
import fr.egl.net.UDP_Server;
import fr.egl.opengl.shaders.EGL_ShaderManager;
import fr.egl.widgets.code_editor.JCodeTextArea;
import fr.egl.widgets.code_editor.syntax.GLSL_Syntax;

public class MainEditor {

	static int size = 14;


	public static void makeDefaultLookAndFeel(Component component) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			SwingUtilities.updateComponentTreeUI(component);
		} catch (Exception e) {e.printStackTrace();}
	}

	public static GL_Context context; 

	static JTextArea console ;

	static boolean autocompile = true;

	static JTabbedPane tabPanel ;

	static JSplitPane splitPaneH;
	static Hashtable<String, Integer> tabMap = new Hashtable<>();
	static Vector<JCodeTextArea> OpenEditors = new Vector<>();

	static File lockFile = null;

	public static JFrame frame ;
	public static void main(String[] args) {

		File lock = new File("./data/lock.net");
		if (lock.exists()){
			// There is a good chance another instance is running.
			try{
				ReadableDocument doc = ReadableDocument.build("./data/lock.net");
				int port = Integer.valueOf(doc.getNextLine());
				try{
					new UDP_Server(port, null);
					lock.delete();
				}catch(Exception e){
					String message = "popup";
					for(String a : args)
						message += " "+a.replace(" ", "\\ ");
					//JOptionPane.showMessageDialog(null, "sending '"+message+"' on port " + port );
					new UDP_Client("127.0.0.1", port).send(message);
					Thread.sleep(100);
					System.exit(0);		
				}
			}catch(Exception e2){ JOptionPane.showMessageDialog(null, "Problem occured during multiple instance check");}	
		}

		try{
			UDP_Server ser = new UDP_Server(0, new IP_Analyser() {			
				@Override
				public void messageReceived(Socket s, String ip, int port, String message, Object... arguments) {
					//System.out.println(message);
					if (message.startsWith("popup")){
						java.awt.EventQueue.invokeLater(new Runnable() {
							@Override
							public void run() {
								frame.setAlwaysOnTop(true);
								frame.requestFocus();
								frame.toFront();
								frame.repaint();
								frame.setAlwaysOnTop(false);
							}
						});
						String[] argsF = message.replace("popup","").split(" ");
						if (argsF.length>0){
							for(String f : argsF){
								File fl = new File(f);
								if (fl.exists())
									loadFile(fl);
							}
						}
					}
				}
			});
			int port = ser.getPort();
			PrintStream ps = new PrintStream(lock);
			ps.println(port);
			ps.flush();
			ps.close();

		}catch(Exception e){	JOptionPane.showMessageDialog(null, "Problem occured during multiple instance check");		}				


		frame = new JFrame("GLSL Integrated Developpement Environment - v0.2");

		Vector<Image> icons = new Vector<>();
		icons.add(new ImageIcon("./data/icon.png").getImage());
		icons.add(new ImageIcon("./data/icon32.png").getImage());
		frame.setIconImages(icons);

		int splitH = 250; 
		size = 14;
		frame.setBounds(0,0,1900,1080);
		frame.getContentPane().setLayout(new BorderLayout());
		try {
			String [] windowsProp = ReadableDocument.getAsString("./data/window.cfg").split(" ");			
			frame.setBounds(Integer.valueOf(windowsProp[0]), Integer.valueOf(windowsProp[1]),Integer.valueOf(windowsProp[2]), Integer.valueOf(windowsProp[3]));
			size = Integer.valueOf(windowsProp[4]);
			splitH = Integer.valueOf(windowsProp[5]);
		} catch (Exception e) {
			e.printStackTrace();
		}

		makeDefaultLookAndFeel(frame);


		final String[] argsF = args;
		new Thread(){
			public void run(){
				try {
					context = new GL_Context();
					frame.getContentPane().add(BorderLayout.SOUTH,context);
					context.setPreferredSize(new Dimension(16,16));

					context.addWaitingMethod(new Runnable() {

						@Override
						public void run() {

							try{
								ReadableDocument session = ReadableDocument.build("./data/session.sav");
								while(session.hasMoreLine()){
									String[] desc = session.getNextLine().split(Pattern.quote("|-|"));
									File fl = new File(desc[0]);
									if (fl.exists()){
										Vector<ShaderType> types = new Vector<>();
										for(int i=1;i<desc.length;i++){
											for(ShaderType t : ShaderType.values())
												if (t.toString().equals(desc[i])){
													types.add(t);
												}
										}
										loadFile(fl,types,false);
										Thread.sleep(100);
									}
								}
							}catch(Exception e){e.printStackTrace();}

							if (argsF.length>0){
								for(String f : argsF){
									File fl = new File(f);
									if (fl.exists())
										loadFile(fl);

								}
							}

						}
					});

				} catch (LWJGLException e1) {
					context = null;
				}
			}
		}.start();


		tabPanel = new JTabbedPane();

		console = new JTextArea();
		console.setBackground(new Color(240,240,250));
		console.setForeground(Color.black);

		splitPaneH = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				tabPanel, console);


		//Provide minimum sizes for the two components in the split pane
		Dimension minimumSize = new Dimension(100, 50);		

		tabPanel.setMinimumSize(minimumSize);




		TransferHandler handler =   new TransferHandler() {

			@Override
			public boolean canImport(TransferHandler.TransferSupport info) {
				// we only import FileList
				if (!info.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
					return false;
				}
				return true;
			}

			@Override
			public boolean importData(TransferHandler.TransferSupport info) {
				if (!info.isDrop()) {
					return false;
				}

				// Check for FileList flavor
				if (!info.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
					displayDropLocation("List doesn't accept a drop of this type.");
					return false;
				}

				// Get the fileList that is being dropped.
				Transferable t = info.getTransferable();
				List<File> data;
				try {
					data = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
				} 
				catch (Exception e) { return false; }

				for (File file : data) {
					loadFile(file);
				}

				return true;
			}

			private void displayDropLocation(String string) {
				System.out.println(string);
			}
		};
		tabPanel.setTransferHandler(handler);



		frame.getContentPane().add(BorderLayout.CENTER, splitPaneH);
		MainMenu.createMenu(frame);

		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setVisible(true);

		frame.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {

				Quit();				
			}			
		});
		splitPaneH.setDividerLocation(splitH);

		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					File lock = new File("./data/lock.net");
					if (lock.exists())
						lock.delete();
				} catch (Exception e) {}
			}
		});

	}


	static Cursor hand = new Cursor(Cursor.HAND_CURSOR);
	static Cursor arrow = new Cursor(Cursor.DEFAULT_CURSOR);

	public static void loadFile(final File p) {
		loadFile(p, null,true);
	}
	public static void loadFile(final File p,final Vector<ShaderType> types_in) {
		loadFile(p, types_in, true);
	}
	public static void loadFile(final File p, final Vector<ShaderType> types_in, boolean thread) {

		if (tabMap.get(p.getAbsolutePath())!=null){
			tabPanel.setSelectedIndex(tabMap.get(p.getAbsolutePath()));
			return;
		}

		if (thread){
			new Thread(){ public void run(){
				routine_createEditor(p, types_in);
			}}.start();
		}
		else
			routine_createEditor(p, types_in);

	}

	private static void routine_createEditor(final File p, final Vector<ShaderType> types_in) {
		Vector<ShaderType> types = types_in;
		MainMenu.default_path = p.getParentFile().getAbsolutePath();

		ReadableDocument doc = ReadableDocument.build(p.getAbsolutePath());
		Vector<String> sections = new Vector<>();
		Hashtable<String, String> inclusion = new  Hashtable<>();
		while (doc.hasMoreLine()){
			String n = doc.getNextLine();
			if (n.trim().startsWith("#?")){
				if(!n.replace("#?", "").trim().equals("SHARED"))
					sections.add(n.replace("#?", "").trim());
			}
			if (n.trim().startsWith("#INCLUDE")){
				String includeName = n.replace("#INCLUDE","").trim();
				File local = new File("./includes/"+includeName+".glsl");
				if (!local.exists()){
					JFileChooser chooser = new JFileChooser(MainMenu.default_path);
					chooser.setDialogTitle("Ouvrir GLSL inclusion : "+includeName);
					chooser.setFileFilter(new FileFilter() {			 
						@Override
						public String getDescription() {return ".glsl (GLSL Shaders)";}			
						@Override
						public boolean accept(File f) {return f.isDirectory() || f.getName().toLowerCase().endsWith(".glsl");}
					});
					int res = chooser.showOpenDialog(MainEditor.frame);
					if (res == JFileChooser.APPROVE_OPTION){
						File f = chooser.getSelectedFile();
						String content = ReadableDocument.build(f.getAbsolutePath()).getAsString().replace("\n", " ");
						inclusion.put(n, content);	
						try{
							PrintStream pl = new PrintStream(local);
							pl.print(content);
							pl.close();
						}catch(Exception e){
						}
					}			
				}else{
					String content = ReadableDocument.build(local.getAbsolutePath()).getAsString().replace("\n", " ");
					inclusion.put(n, content);	
				}
			}
		}	
		if (sections.size()==0)
			sections.add("--Full Code");

		if (types==null || types.size() != sections.size())
			types = TypeSelector.selectTypes(p.getName(), sections);
		if (types == null) return;

		JCodeTextArea editor = buildEditor(doc.getAsString(),p, sections, types,inclusion);
		Border empty = new EmptyBorder(2,20,0,0);
		editor.setBorder(empty);

		tabPanel.add(editor);
		ButtonTabComponent but = new ButtonTabComponent(tabPanel, editor);

		tabPanel.setTabComponentAt(OpenEditors.size(),but);
		editor.setSaveListener(but);

		tabMap.put(p.getAbsolutePath(),tabPanel.getTabCount()-1);
		OpenEditors.add(editor);
		editor.saved(true);

		compileShader(editor,true);
	}

	static ImageIcon icon = createImageIcon("data/close.png");


	/** Returns an ImageIcon, or null if the path was invalid. */
	protected static ImageIcon createImageIcon(String path) {
		return new ImageIcon(path);        
	}

	public static JCodeTextArea buildEditor( String content, File p, Vector<String> sections, Vector<ShaderType> types, Hashtable<String, String> inclusion ){

		JCodeTextArea script_text = new JCodeTextArea(p, sections, types, inclusion);

		script_text.setFont(new Font("Consolas",Font.PLAIN,size));
		script_text.getPainter().setFont(new Font("Consolas",Font.PLAIN,size));
		script_text.setTokenMarker(new GLSL_Syntax());
		script_text.initText(content);
		script_text.scrollTo(0, 0);

		script_text.addMouseWheelListener(new MouseWheelListener() {
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				if (e.isControlDown()){
					size = Math.max(5,size - e.getUnitsToScroll());
					Font font = new Font("Consolas",Font.PLAIN,size);
					((JCodeTextArea) e.getSource()).setFont(font);
					for(JCodeTextArea area : OpenEditors){
						area.getPainter().setFont(font);
						area.setFont(font);
						area.repaint();
					}

				}
			}
		});

		return script_text;
	}



	public static void compileShader(final JCodeTextArea source) {
		compileShader(source,false);
	}

	public static void compileShader(final JCodeTextArea source, boolean force) {

		if (!autocompile && !force) return;

		context.addWaitingMethod( new Runnable(){public void run(){
			System.out.println("Starting Compilation");
			Vector<String> output = new Vector<String>();

			boolean compiled = true;
			Vector<String> ActiveList = new Vector<>();

			for(int i=0;i<source.types.size();i++){

				try {
					PrintStream ps = new PrintStream("./data/tmp.glsl");
					ps.print(source.getTextWithInclusion());
					ps.flush();
					ps.close();

					String path = "./data/tmp.glsl#?"+source.sections.get(i);
					if (source.sections.get(i).equals("--Full Code"))
						path = "./data/tmp.glsl";

					switch(source.types.get(i)){
					case VERTEX :
						System.out.println("Vertex Program compilation");
						compiled &= EGL_ShaderManager.loadVertexProgram( path, output,ActiveList);
						break;
					case TESS_CONT : 
						System.out.println("Tesselation Control Program compilation");
						compiled &= EGL_ShaderManager.loadTessControlProgram( path, output,ActiveList);
						break;
					case TESS_EVAL : 
						System.out.println("Tesselation Evaluation Program compilation");
						compiled &= EGL_ShaderManager.loadTessEvalProgram( path, output,ActiveList);
						break;
					case GEOMETRY: 
						System.out.println("Geometry Program compilation");
						compiled &= EGL_ShaderManager.loadGeometryProgram( path, output,ActiveList);
						break;
					case FRAGMENT : 
						System.out.println("Vertex Program compilation");
						compiled &= EGL_ShaderManager.loadFragmentProgram( path, output,ActiveList);
						break;
					case COMPUTE :  
						System.out.println("Compute Program compilation");
						compiled &= EGL_ShaderManager.loadComputeProgram( path, output,ActiveList);
						break;
					}

					source.clearErrors();
					console.setText("");

					for(String line : output){
						console.setText(line+"\n"+console.getText());
						String [] parts = line.split(":");
						if (parts.length>1){
							try{
								int line_index = Integer.valueOf(parts[0].replace("0(", "").replace(")", "").trim())-1;
								String error = "";
								for(int e=1;e<parts.length;e++)
									error += parts[e];								
								source.addErrorOnLine(line_index, 0, source.getLineText(line_index).length(), Kind.ERROR,error );
							}catch(Exception e){}
						}
					}

				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			console.setText(console.getText()+"\n\n Compilation Status : " + compiled);

			source.setShaderInUni(ActiveList);

			source.repaint();

		}});

	}

	public static void saveFile(JCodeTextArea shaderSource) {
		shaderSource.save();
		compileShader(shaderSource,true);
	}
	public static void saveAsFile(JCodeTextArea shaderSource) {

		JFileChooser chooser = new JFileChooser(MainMenu.default_path);
		chooser.setDialogTitle("Enregistrer sous...");
		chooser.setFileFilter(new FileFilter() {			
			@Override
			public String getDescription() {return ".glsl (GLSL Shaders)";}			
			@Override
			public boolean accept(File f) {return f.isDirectory() || f.getName().toLowerCase().endsWith(".glsl");}
		});
		int res = chooser.showOpenDialog(MainEditor.frame);
		if (res == JFileChooser.APPROVE_OPTION){
			File f = chooser.getSelectedFile();
			MainMenu.default_path = f.getParentFile().getAbsolutePath();
			shaderSource.saveAs(f);	
			compileShader(shaderSource,true);		
		}	
	}

	public static void Quit() {


		try {
			PrintStream ps = new PrintStream("./data/window.cfg");
			ps.print(frame.getX()+" "+frame.getY()+" "+frame.getWidth()+" "+frame.getHeight()+" "+size+" "+splitPaneH.getDividerLocation());
			ps.close();
		} catch (FileNotFoundException e) {}

		boolean unsaved = false;
		for(JCodeTextArea j : OpenEditors)
			unsaved |=  j.isUnsaved();

		if (!unsaved || JOptionPane.showConfirmDialog(frame, "Certains fichier ne sont pas sauvegard�s. Voulez vous quitter ?","Confirmer",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){

			frame.dispose();
			try {

				PrintStream ps = new PrintStream("./data/session.sav");
				for(JCodeTextArea shaderCode : OpenEditors){
					ps.print(shaderCode.associatedFile.getAbsolutePath()+"|-|");
					for(ShaderType s : shaderCode.types){
						ps.print(s.toString()+"|-|");
					}
					ps.println();
				}
				ps.close();

			} catch (FileNotFoundException e) {
			}

			try {
				File lock = new File("./data/lock.net");
				if (lock.exists())
					lock.delete();
			} catch (Exception e) {}
			System.exit(0);
		}


	}
	public static void removeShader(JCodeTextArea shaderCode) {
		OpenEditors.remove(shaderCode);
		tabMap.remove(shaderCode.associatedFile.getAbsolutePath());		
	}

}
