package fr.egl.glsl_editor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Vector;

import javax.swing.Action;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.filechooser.FileFilter;

import fr.egl.glsl_editor.TypeSelector.ShaderType;
import fr.egl.libs.GL_Context;
import fr.egl.libs.ReadableDocument;
import fr.egl.widgets.code_editor.JCodeTextArea;

public class MainMenu {

	public static String default_path = "";
	
	public static void createMenu( JFrame frame ){
		
		JMenuBar menuBar = new JMenuBar();
		
		JMenu menu = new JMenu("Fichiers");
		{

			JMenuItem newFile = new JMenuItem("Nouveau");		
			newFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
			
			newFile.setMnemonic(KeyEvent.VK_N);
			newFile.getAccessibleContext().setAccessibleDescription("Cr�er un shader GLSL");
			menu.add(newFile);
			newFile.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					newFile();
				}

			});

			menu.addSeparator();
			
			JMenuItem open = new JMenuItem("Ouvrir..");		
			open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
			try{
			default_path = ReadableDocument.build("./data/last_open.log").getNextLine();
			}catch(Exception e){ default_path = "./";}
			
			open.setMnemonic(KeyEvent.VK_O);
			open.getAccessibleContext().setAccessibleDescription("Ouvrir un shader GLSL");
			menu.add(open);
			open.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					loadFile();
				}
			});
	
			JMenu openRecent = new JMenu("Ouvert r�cemment...");		
			try{
				ReadableDocument doc = ReadableDocument.build("./data/history.log");
				doc.revertLines();
				int i=0;
				while (doc.hasMoreLine() && i<15){
					String path = doc.getNextLine();
					File p = new File(path);
					if (p.exists()){
						JMenuItem openre = new JMenuItem(p.getName() + " ("+p.getParentFile().getAbsolutePath()+")");							
						openRecent.add(openre);
						openre.addActionListener(new ActionListener() {							
							@Override
							public void actionPerformed(ActionEvent e) {
								MainEditor.loadFile(p);
							}
						});
					}
					i++;
				}
			}catch(Exception e){ }
			
			openRecent.getAccessibleContext().setAccessibleDescription("List des ouvertures r�cent");
			menu.add(openRecent);
			menu.addSeparator();
			
			
			
			JMenuItem save = new JMenuItem("Enregistrer");		
			save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));			
			save.getAccessibleContext().setAccessibleDescription("Sauvegarder");
			menu.add(save);
			save.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					if (MainEditor.tabPanel.getSelectedComponent() != null)
						MainEditor.saveFile(( JCodeTextArea ) (MainEditor.tabPanel.getSelectedComponent()));
				}
			});

			JMenuItem saveAs = new JMenuItem("Enregistrer sous...");					
			saveAs.getAccessibleContext().setAccessibleDescription("Sauvegarder sous...");
			menu.add(saveAs);
			saveAs.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					if (MainEditor.tabPanel.getSelectedComponent() != null)
						MainEditor.saveAsFile(( JCodeTextArea ) (MainEditor.tabPanel.getSelectedComponent()));
				}
			});
			
			menu.addSeparator();
			

			JMenuItem Quit = new JMenuItem("Quitter");		
			Quit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));				
			Quit.getAccessibleContext().setAccessibleDescription("Quitter");
			menu.add(Quit);
			Quit.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					MainEditor.Quit();
				}
			});
		}
		menuBar.add(menu);

		JMenu menuOption = new JMenu("Compilation");
		{
			ReadableDocument doc = ReadableDocument.build("./data/autocomp.cfg");
			MainEditor.autocompile = doc.getNextLine().equals("1");
			
			final JMenuItem Autocompile = new JCheckBoxMenuItem("Auto-compilation (delais 3s)",MainEditor.autocompile);		
			Autocompile.getAccessibleContext().setAccessibleDescription("Activer/d�sactiver la compilation auto");
			menuOption.add(Autocompile);
			Autocompile.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					MainEditor.autocompile = Autocompile.isSelected();
					new Thread(){public void run(){
						PrintStream ps;
						try {
							ps = new PrintStream("./data/autocomp.cfg");
							ps.print(MainEditor.autocompile?"1":"0");
							ps.close();
						} catch (FileNotFoundException e1) {}
					}}.start();
				}
			});
			
			final JMenuItem compileNow = new JMenuItem("Compiler le fichier en cours...");		
			compileNow.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK));
			compileNow.getAccessibleContext().setAccessibleDescription("Lancer la compilation");
			menuOption.add(compileNow);
			compileNow.addActionListener(new ActionListener() {							
				@Override
				public void actionPerformed(ActionEvent e) {
					if (MainEditor.tabPanel.getSelectedComponent() != null)
						MainEditor.compileShader(( JCodeTextArea ) (MainEditor.tabPanel.getSelectedComponent()), true);
				}
			});
			
			
		}
		menuBar.add(menuOption);
		
		frame.setJMenuBar(menuBar);
	}
	
	public static void loadFile( ) {
		JFileChooser chooser = new JFileChooser(default_path);
		chooser.setFileFilter(new FileFilter() {			
			@Override
			public String getDescription() {return ".glsl (GLSL Shaders)";}			
			@Override
			public boolean accept(File f) {return f.isDirectory() || f.getName().toLowerCase().endsWith(".glsl");}
		});
		int res = chooser.showOpenDialog(MainEditor.frame);
		if (res == JFileChooser.APPROVE_OPTION){
			File f = chooser.getSelectedFile();
			
			try{
				PrintStream ps = new PrintStream("./data/last_open.log");
				ps.print(default_path = f.getParentFile().getAbsolutePath());
				ps.close();
			}catch(Exception e){}

			try{
				PrintStream ps = new PrintStream(new FileOutputStream("./data/history.log", true));
				ps.println(f.getAbsolutePath());
				ps.close();
			}catch(Exception e){}
			
			MainEditor.loadFile(f);
		}
	}

	private static void newFile() {

		new Thread(){public void run(){
			
		Vector<ShaderType> sectionToCreate = TypeSelector.selectNew();
		if (sectionToCreate == null) return;
		
		String code = "\n";
		if (sectionToCreate.size()>1){
			code += "\n//=========================================\n";
			code += "\n#? SHARED \n";
			code += "\n//=========================================\n";
		}
		code += "#version "+GL_Context.GLSLVersion+"\n";
		code += "precision highp float;\n\n";
		
		for(ShaderType type : sectionToCreate){
			if (sectionToCreate.size()>1){
				code += "\n//=========================================\n";
				code += "\n#? "+type.toString()+" \n";
				code += "\n//=========================================\n";
			}
			code += "\nvoid main(){\n\t\n\t\n\t\n}\n\n";
		}
		
		JFileChooser chooser = new JFileChooser(MainMenu.default_path);
		chooser.setDialogTitle("Enregistrer sous...");
		chooser.setFileFilter(new FileFilter() {			
			@Override
			public String getDescription() {return ".glsl (GLSL Shaders)";}			
			@Override
			public boolean accept(File f) {return f.isDirectory() || f.getName().toLowerCase().endsWith(".glsl");}
		});
		int res = chooser.showOpenDialog(MainEditor.frame);
		if (res == JFileChooser.APPROVE_OPTION){
			File f = chooser.getSelectedFile();
			if (!f.exists() || JOptionPane.showConfirmDialog(MainEditor.frame, "Le fichier existe d�j�. Ecraser ?", "Confirmer", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
				try{
					PrintStream ps = new PrintStream(f);
					ps.print(code);
					ps.close();
					
					try{
						ps = new PrintStream("./data/last_open.log");
						ps.print(default_path = f.getParentFile().getAbsolutePath());
						ps.close();
					}catch(Exception e){}

					try{
						ps = new PrintStream(new FileOutputStream("./data/history.log", true));
						ps.println(f.getAbsolutePath());
						ps.close();
					}catch(Exception e){}
					
					MainEditor.loadFile(f,sectionToCreate );
				}catch(Exception e) {}
			}		
		}			
		}}.start();
		
	}
	
}
