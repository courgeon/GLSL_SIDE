package fr.egl.opengl.shaders;

public class EGL_Shader_Injection {
	
	public String key;
	public String value;
	
	public EGL_Shader_Injection(String key, String value){
		this.key = key;
		this.value = value;
	}

}
