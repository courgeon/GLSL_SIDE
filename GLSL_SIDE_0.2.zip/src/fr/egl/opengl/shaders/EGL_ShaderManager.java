/*
 * Copyright (c) 2006-2013 Matthieu COURGEON
 * 
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, and to alter it and redistribute it
 * freely, subject to the following restrictions:
 * 
 *    1. The origin of this software must not be misrepresented; you must not
 *    claim that you wrote the original software. If you use this software
 *    in a product, an acknowledgment in the product documentation would be
 *    appreciated but is not required.
 * 
 *    2. Altered source versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 * 
 *    3. This notice may not be removed or altered from any source
 *    distribution.
 */

package fr.egl.opengl.shaders;

import static org.lwjgl.opengl.GL11.GL_NO_ERROR;
import static org.lwjgl.opengl.GL11.glGetError;
import static org.lwjgl.opengl.GL11.glGetInteger;
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL20.*;

import java.awt.Color;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Vector;

import javax.swing.JOptionPane;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL32;
import org.lwjgl.opengl.GL40;
import org.lwjgl.opengl.GL43;
import org.lwjgl.opengl.GLContext;

import fr.egl.libs.EGL_BufferManager;
import fr.egl.libs.GL_Context;
import fr.egl.libs.ReadableDocument;


public class EGL_ShaderManager {


	private static IntBuffer bf16 = EGL_BufferManager.allocateIntBuffer(16);

	public static boolean glError() {
		return glGetError() != GL_NO_ERROR;
	}

	static File tempsfile ;

	public static byte[] getProgramCode(String filename, String type, EGL_Shader_Injection [] injection, String [] defs){
		return getProgramCode(filename, type ,true, injection, defs);
	}
	public static byte[] getProgramCode(String filename, String type, boolean allowUnzip, EGL_Shader_Injection [] injection, String [] defs)
	{

		System.out.print("LOADING SHADER : " + filename + "   to actual file : ");

		String RealFileName = filename.split("\\#\\?")[0];


		if (filename.contains("#?")){

			String balise_name = filename.split("\\#\\?")[1].toLowerCase();

			ReadableDocument doc = ReadableDocument.build(filename.split("\\#\\?")[0],true);

			String section = "";

			boolean isIn = false;
			while (doc.hasMoreLine()){
				String line = doc.getNextLine().trim();
				if (line.startsWith("#?")){

					System.out.println("TRAITEMENT : " + line);

					line = line.replace("#?", "").trim();
					String[] tagNames = line.split(",");

					isIn = false;
					for(String tag : tagNames)
						isIn = 	isIn ||	tag.trim().toLowerCase().equals(balise_name)  ;

					isIn = isIn 
							|| 	line.equals("SHARED") 
							|| (line.equals("SHARED_VP") && type.equals("VP")) 
							|| (line.equals("SHARED_GS") && type.equals("GS")) 
							|| (line.equals("SHARED_FS") && type.equals("FS")) 
							|| (line.equals("SHARED_TCS") && type.equals("TCS")) 
							|| (line.equals("SHARED_TES") && type.equals("TES"))
							|| (line.equals("SHARED_CS") && type.equals("CS")) ;

					section += "\n";
				}
				else
					if (isIn && ! line.startsWith("//"))
						section = section + line  + "\n";
					else
						section += "\n";
			}

			if (section.length()==0){
				/* SECTION NOT FOUND */
				/* TODO */

			}

			try
			{


				File tmp = new File("./data/tmp-compile.glsl");
				PrintStream ps = new PrintStream(tmp);
				ps.print(section);
				ps.close();
				filename = tmp.getAbsolutePath();
			}
			catch (Exception e)
			{
				/* TODO */
			}

		}


		System.out.println(filename);

		if (new File(filename).exists()){


			byte[] shaderCode = null;
			try
			{
				InputStream fileInputStream = new FileInputStream(filename);
				DataInputStream dataStream = new DataInputStream(fileInputStream);
				dataStream.readFully(shaderCode = new byte[  fileInputStream.available() ]);

				fileInputStream.close();
				dataStream.close();


				String sourceCode = new String(shaderCode);


				sourceCode = IF_DEF(sourceCode,defs);

				sourceCode = inject(sourceCode, injection);

				sourceCode = versionCheck(sourceCode);
				
				
				shaderCode = sourceCode.getBytes();
				
				


			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

			return shaderCode;
		}else{
			System.err.println("SHADER NOT FOUND : " + filename);

			return null;
		}

	}


	private static String versionCheck(String code) {

		if (code.contains("#version ")){
			String parts [] = code.split("#version ");
			parts[1] = parts[1].trim();
			int v = Integer.valueOf(parts[1].substring(0, 3));
			if (v>GL_Context.GLSLVersion){
				System.err.println("Shader version " + v +" is higher than compiler version " + GL_Context.GLSLVersion + ". Replacing version, but it might generate bug" );
				code = parts[0]+"#version "+GL_Context.GLSLVersion + "\n"+ parts[1].substring(3);
			}
			
		}else{
			code = "#version "+GL_Context.GLSLVersion + "\n" + code;
		}
		

		/* Apparently useless ... :(
		  
		 
		String [] start_version = code.split("#version");
		String [] version_code = start_version[1].split("\n",2);
		
		code = start_version[0]+"#version"+version_code[0]+"\n"+
				"#pragma optimize(off)\n"+
				"#pragma debug(on)\n"+ version_code[1];
				
			*/	
		return code;

	}
	private static String inject(String sourceCode,
			EGL_Shader_Injection[] injection) {
		for(EGL_Shader_Injection inj : injection){
			sourceCode = sourceCode.replace(inj.key, inj.value);
		}
		return sourceCode;
	}
	private static String IF_DEF(String section, String ... defs) {


		String [] lines = section.split("\n");

		String reconstructed = "";

		boolean ignoring = false;
		String lastIgnoringDef = "";

		for(String line : lines){

			if (line.startsWith("#IFDEF ") && !ignoring){


				reconstructed += "\n";
				String defReq = line.replace("#IFDEF ","").trim();
				ignoring = true;
				String lIDef = defReq;

				for(String  d : defs)
					if (d.equals(defReq)){
						ignoring=false;
					}
				if (ignoring)
					lastIgnoringDef = lIDef;

			}
			else			
				if (line.startsWith("#END ")){
					reconstructed += "\n";

					String defReq = line.replace("#END ","").trim();
					if (defReq.equals(lastIgnoringDef))
						ignoring = false;
				}else if (!ignoring)
					reconstructed += line + "\n";
				else
					reconstructed += "\n";


		}


		return reconstructed.replace("#?","//");
	}


	public static int createProgramID(){

		int programObject  = GL20.glCreateProgram();

		return programObject;
	}

	public static boolean loadProgram(String fileName, Vector<String> result,int gl_type, String code, Vector<String> active_list){

		int pgID = glCreateProgram();
		int subShader = glCreateShader(gl_type);

		byte[] ShaderSourceByteBuffer = EGL_ShaderManager.getProgramCode(fileName, code, new EGL_Shader_Injection[0] ,new String[0]);

		ByteBuffer shaderProgram = BufferUtils.createByteBuffer(ShaderSourceByteBuffer.length);
		shaderProgram.put(ShaderSourceByteBuffer);
		shaderProgram.flip();
		glShaderSource(subShader, shaderProgram);
		glCompileShader(subShader);

		bf16.rewind();
		glGetShader(subShader, GL_COMPILE_STATUS, bf16);
		boolean success = ! (bf16.get(0)==0) ;

		success &= EGL_ShaderManager.getLogInfo(subShader, result);

		glAttachShader(pgID, subShader);
		glValidateProgram(pgID);
		
		getShaderUniformsAndAttribute(subShader,active_list);

		return success;
	}

	public static boolean loadVertexProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL_VERTEX_SHADER, "VP",active_list);
	}
	public static boolean loadGeometryProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL32.GL_GEOMETRY_SHADER, "GS",active_list);
	}
	public static boolean loadFragmentProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL_FRAGMENT_SHADER, "FS",active_list);
	}
	public static boolean loadTessControlProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL40.GL_TESS_CONTROL_SHADER, "TCS",active_list);
	}
	public static boolean loadTessEvalProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL40.GL_TESS_EVALUATION_SHADER, "TES",active_list);
	}
	public static boolean loadComputeProgram( String fileName, Vector<String> result, Vector<String> active_list){
		return loadProgram( fileName,result, GL43.GL_COMPUTE_SHADER, "CS",active_list);
	}



	public static boolean getLogInfo(int obj, Vector<String> res)
	{

		IntBuffer iVal = BufferUtils.createIntBuffer(1);
		glGetShader(obj, GL_INFO_LOG_LENGTH, iVal);

		int length = iVal.get();
		if (length > 1)
		{
			// We have some info we need to output.
			ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
			iVal.flip();
			glGetShaderInfoLog(obj,  iVal, infoLog);
			byte[] infoBytes = new byte[length];
			infoLog.get(infoBytes);
			String out = new String(infoBytes);

			for (String line : out.split("\n")){
				if (line.length()>5)
					res.add(line);

			}
			return false;
		}else
			return true;
	}



	public static void displayProgramInfo(int shaderID) {
		IntBuffer iVal = BufferUtils.createIntBuffer(1);
		glGetProgram(shaderID, GL_INFO_LOG_LENGTH, iVal);

		int length = iVal.get();
		if (length > 1)
		{
			// We have some info we need to output.
			ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
			iVal.flip();
			glGetProgramInfoLog (shaderID,  iVal, infoLog);
			byte[] infoBytes = new byte[length];
			infoLog.get(infoBytes);
			String out = new String(infoBytes);


			//EGL_Log.Log("----------------------------------------");
			//EGL_Log.Log("\t\tCompiler output:");
			for (String line : out.split("\n")){
				if (line.length()>5)
					if (line.contains("error")){
						System.err.println("\t\t"+line);
						//EGL_Log.Log("\t\t"+line);
						/* TODO */
					}
					else{
						/* TODO */
					}
			}
			//EGL_Log.Log("----------------------------------------");

		}/*
		try {
			Util.checkGLError();
		} catch(Exception e){e.printStackTrace();//EGL_Log.Log("GL Error");}
		 */

	}



	public static void printValidateLogInfo(int obj)
	{

		IntBuffer iVal = BufferUtils.createIntBuffer(1);
		glGetProgram(obj, GL_INFO_LOG_LENGTH, iVal);



		int length = iVal.get();

		if (length > 1)
		{
			// We have some info we need to output.

			ByteBuffer infoLog = BufferUtils.createByteBuffer(length);
			iVal.flip();
			glGetProgramInfoLog(obj,  iVal, infoLog);

			byte[] infoBytes = new byte[length];
			infoLog.get(infoBytes);
			String out = new String(infoBytes);


			//EGL_Log.Log("----------------------------------------");
			//EGL_Log.Log("\t\tValidate output:");
			for (String line : out.split("\n")){
				if (line.length()>5)
					if (line.contains("error")){
						//EGL_Log.Log("\t\t"+line);
						System.err.println("\t\t"+line);
						/* TODO */
					}
					else{
						/* TODO */
					}
			}
			//EGL_Log.Log("----------------------------------------");

		}
		/*
		try {
			Util.checkGLError();
		} catch(Exception e){e.printStackTrace();//EGL_Log.Log("GL Error");}
		 */
	}
	static ByteBuffer name;

	public static void getShaderUniformsAndAttribute(int program, Vector<String> res){

		try{

			int count = glGetProgrami(program, GL_ACTIVE_ATTRIBUTES );
			for (int i = 0; i < count; i++){
				String v = glGetActiveAttrib(program, i, 64);
				if (!res.contains(v)) res.add(v);
			}

			count = glGetProgrami(program, GL_ACTIVE_UNIFORMS );
			for (int i = 0; i < count; i++)	{	
				String v = glGetActiveUniform(program, i, 64);
				if (!res.contains(v)) res.add(v);
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	public static ByteBuffer createByteString(String s, boolean nullTerminated) {

		int length = s.length() + (nullTerminated ? 1 : 0);

		ByteBuffer buff = BufferUtils.createByteBuffer(length);
		buff.put(s.getBytes());

		if (nullTerminated)
			buff.put((byte) 0);

		buff.flip();

		return buff;
	}


}
